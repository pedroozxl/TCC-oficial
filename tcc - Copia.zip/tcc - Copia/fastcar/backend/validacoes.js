// ============================================================
// validacoes.js  -  funções pequenas para conferir os dados recebidos
// ============================================================

// Confere se o CPF é válido (calcula os 2 dígitos verificadores)
function cpfValido(cpf) {
  cpf = String(cpf).replace(/\D/g, ''); // tira tudo que não é número

  if (cpf.length !== 11) {
    return false;
  }
  if (/^(\d)\1{10}$/.test(cpf)) { // 111.111.111-11, 000.000.000-00...
    return false;
  }

  // Calcula cada um dos 2 dígitos verificadores
  for (let tamanho = 9; tamanho <= 10; tamanho++) {
    let soma = 0;
    for (let i = 0; i < tamanho; i++) {
      soma += Number(cpf[i]) * (tamanho + 1 - i);
    }
    const digito = ((soma * 10) % 11) % 10;
    if (digito !== Number(cpf[tamanho])) {
      return false;
    }
  }
  return true;
}

function emailValido(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email));
}

// Senha: pelo menos 6 caracteres
function senhaValida(senha) {
  return typeof senha === 'string' && senha.length >= 6;
}

// Data de hoje no formato AAAA-MM-DD
function hoje() {
  const d = new Date();
  const mes = String(d.getMonth() + 1).padStart(2, '0');
  const dia = String(d.getDate()).padStart(2, '0');
  return d.getFullYear() + '-' + mes + '-' + dia;
}

// Quantidade de diárias entre duas datas (mínimo 1)
function contarDias(inicio, fim) {
  const dias = Math.round((new Date(fim) - new Date(inicio)) / 86400000);
  return dias < 1 ? 1 : dias;
}

module.exports = { cpfValido, emailValido, senhaValida, hoje, contarDias };
