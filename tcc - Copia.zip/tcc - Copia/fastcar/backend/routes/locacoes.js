// ============================================================
// routes/locacoes.js  -  locações (aluguéis)
// ============================================================
// GET  /locacoes                lista (funcionários; o vendedor vê só as dele)
// GET  /locacoes/minhas         lista as locações do cliente logado
// POST /locacoes                registra uma locação (cliente pelo site OU funcionário)
// PUT  /locacoes/:id/finalizar  devolve o veículo (funcionários)
// PUT  /locacoes/:id/cancelar   cancela (gerente, administrador)
const express = require('express');
const db = require('../database');
const { exigirLogin, exigirCargo } = require('../protecao');
const { hoje, contarDias } = require('../validacoes');

const router = express.Router();
const funcionarios = exigirCargo('VENDEDOR', 'GERENTE', 'ADMINISTRADOR');
const soGerencia = exigirCargo('GERENTE', 'ADMINISTRADOR');

// Consulta base: junta a locação com o nome do cliente e os dados do veículo
const consultaLocacoes = `
  SELECT l.*, c.nome AS cliente_nome, v.marca AS veiculo_marca, v.modelo AS veiculo_modelo,
         v.placa AS veiculo_placa, u.nome AS vendedor_nome
  FROM locacoes l
  JOIN clientes c ON c.id = l.cliente_id
  JOIN veiculos v ON v.id = l.veiculo_id
  LEFT JOIN usuarios u ON u.id = l.vendedor_id`;

// ----- LISTAR (funcionários) -----
router.get('/', funcionarios, (req, res) => {
  let locacoes;
  if (req.session.usuario.cargo === 'VENDEDOR') {
    // vendedor só enxerga o que ele mesmo registrou
    locacoes = db.prepare(consultaLocacoes + ' WHERE l.vendedor_id = ? ORDER BY l.id DESC').all(req.session.usuario.id);
  } else {
    locacoes = db.prepare(consultaLocacoes + ' ORDER BY l.id DESC').all();
  }
  res.json(locacoes);
});

// ----- MINHAS LOCAÇÕES (cliente logado) -----
router.get('/minhas', exigirLogin, (req, res) => {
  const locacoes = db.prepare(consultaLocacoes + ' WHERE c.usuario_id = ? ORDER BY l.id DESC').all(req.session.usuario.id);
  res.json(locacoes);
});

// ----- REGISTRAR UMA LOCAÇÃO -----
// corpo: { veiculo_id, data_inicio, data_fim }  (+ cliente_id quando é um funcionário registrando)
router.post('/', exigirLogin, (req, res) => {
  const usuario = req.session.usuario;
  let clienteId;
  let vendedorId = null;

  if (usuario.cargo === 'CLIENTE') {
    // o cliente só aluga para ele mesmo
    const cliente = db.prepare('SELECT id FROM clientes WHERE usuario_id = ?').get(usuario.id);
    if (!cliente) {
      return res.status(400).json({ erro: 'Cadastro de cliente não encontrado.' });
    }
    clienteId = cliente.id;
  } else {
    clienteId = Number(req.body.cliente_id);
    vendedorId = usuario.id; // fica registrado quem atendeu
    if (!db.prepare('SELECT id FROM clientes WHERE id = ?').get(clienteId)) {
      return res.status(400).json({ erro: 'Escolha um cliente válido.' });
    }
  }

  const inicio = String(req.body.data_inicio || '');
  const fim = String(req.body.data_fim || '');
  if (inicio === '' || fim === '') {
    return res.status(400).json({ erro: 'Informe as datas de retirada e devolução.' });
  }
  if (inicio < hoje()) {
    return res.status(400).json({ erro: 'A retirada não pode ser em uma data passada.' });
  }
  if (fim < inicio) {
    return res.status(400).json({ erro: 'A devolução não pode ser antes da retirada.' });
  }

  const veiculo = db.prepare('SELECT * FROM veiculos WHERE id = ?').get(req.body.veiculo_id);
  if (!veiculo) {
    return res.status(404).json({ erro: 'Veículo não encontrado.' });
  }
  if (veiculo.status !== 'DISPONIVEL') {
    return res.status(400).json({ erro: 'Este veículo não está disponível.' });
  }

  // Se o veículo está em oferta, cobra o preço promocional
  const diaria = veiculo.preco_promocional || veiculo.valor_diaria;
  const total = Math.round(contarDias(inicio, fim) * diaria * 100) / 100;

  const r = db.prepare(`
    INSERT INTO locacoes (cliente_id, veiculo_id, vendedor_id, data_inicio, data_fim, valor_diaria, valor_total, status)
    VALUES (?, ?, ?, ?, ?, ?, ?, 'ATIVA')`)
    .run(clienteId, veiculo.id, vendedorId, inicio, fim, diaria, total);

  // O veículo deixa de estar disponível
  db.prepare("UPDATE veiculos SET status = 'ALUGADO' WHERE id = ?").run(veiculo.id);

  res.status(201).json({ id: Number(r.lastInsertRowid), valor_total: total, valor_diaria: diaria });
});

// Encerra uma locação (finalizar ou cancelar) e libera o veículo
function encerrar(req, res, novoStatus) {
  const locacao = db.prepare('SELECT * FROM locacoes WHERE id = ?').get(req.params.id);
  if (!locacao) {
    return res.status(404).json({ erro: 'Locação não encontrada.' });
  }
  if (locacao.status !== 'ATIVA') {
    return res.status(400).json({ erro: 'Esta locação já foi encerrada.' });
  }
  const usuario = req.session.usuario;
  if (usuario.cargo === 'VENDEDOR' && locacao.vendedor_id !== usuario.id) {
    return res.status(403).json({ erro: 'Você só pode finalizar as locações que registrou.' });
  }

  db.prepare('UPDATE locacoes SET status = ? WHERE id = ?').run(novoStatus, locacao.id);
  db.prepare("UPDATE veiculos SET status = 'DISPONIVEL' WHERE id = ?").run(locacao.veiculo_id);
  res.json({ mensagem: 'Locação ' + novoStatus.toLowerCase() + '.' });
}

router.put('/:id/finalizar', funcionarios, (req, res) => encerrar(req, res, 'FINALIZADA'));
router.put('/:id/cancelar', soGerencia, (req, res) => encerrar(req, res, 'CANCELADA'));

module.exports = router;
