// ============================================================
// routes/auth.js  -  login, logout e cadastro de clientes pelo site
// ============================================================
const express = require('express');
const bcrypt = require('bcryptjs');
const db = require('../database');
const { cpfValido, emailValido, senhaValida } = require('../validacoes');

const router = express.Router();

// POST /auth/login   corpo: { email, senha }
router.post('/login', (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const senha = req.body.senha || '';

  if (email === '' || senha === '') {
    return res.status(400).json({ erro: 'Informe o e-mail e a senha.' });
  }

  // 1) procura o usuário pelo e-mail
  const usuario = db.prepare('SELECT * FROM usuarios WHERE email = ?').get(email);

  // 2) compara a senha digitada com a senha criptografada do banco
  if (!usuario || !bcrypt.compareSync(senha, usuario.senha)) {
    return res.status(401).json({ erro: 'E-mail ou senha incorretos.' });
  }
  if (usuario.ativo !== 1) {
    return res.status(403).json({ erro: 'Esta conta está desativada.' });
  }

  // 3) guarda na sessão quem está logado (nunca guardamos a senha)
  req.session.usuario = { id: usuario.id, nome: usuario.nome, email: usuario.email, cargo: usuario.cargo };
  res.json(req.session.usuario);
});

// POST /auth/logout
router.post('/logout', (req, res) => {
  req.session.destroy(() => {
    res.json({ mensagem: 'Você saiu do sistema.' });
  });
});

// GET /auth/eu   -> diz quem está logado (usuario = null se ninguém)
router.get('/eu', (req, res) => {
  res.json({ usuario: req.session.usuario || null });
});

// POST /auth/cadastro   -> o cliente cria a própria conta pelo site
// corpo: { nome, cpf, telefone, email, data_nascimento, senha }
router.post('/cadastro', (req, res) => {
  const nome = String(req.body.nome || '').trim();
  const cpf = String(req.body.cpf || '').replace(/\D/g, '');
  const telefone = String(req.body.telefone || '').trim();
  const email = String(req.body.email || '').trim().toLowerCase();
  const nascimento = String(req.body.data_nascimento || '');
  const senha = req.body.senha;

  // Validações básicas
  if (nome === '' || telefone === '' || nascimento === '') {
    return res.status(400).json({ erro: 'Preencha todos os campos.' });
  }
  if (!cpfValido(cpf)) {
    return res.status(400).json({ erro: 'CPF inválido.' });
  }
  if (!emailValido(email)) {
    return res.status(400).json({ erro: 'E-mail inválido.' });
  }
  if (!senhaValida(senha)) {
    return res.status(400).json({ erro: 'A senha deve ter pelo menos 6 caracteres.' });
  }
  if (db.prepare('SELECT id FROM usuarios WHERE email = ?').get(email)) {
    return res.status(400).json({ erro: 'Já existe uma conta com este e-mail.' });
  }

  // Se o CPF já foi cadastrado no balcão (sem login) com o MESMO e-mail, só ligamos a conta
  const cliente = db.prepare('SELECT * FROM clientes WHERE cpf = ?').get(cpf);
  if (cliente && (cliente.usuario_id || String(cliente.email || '').toLowerCase() !== email)) {
    return res.status(400).json({ erro: 'CPF já cadastrado.' });
  }

  // Cria o usuário (cargo CLIENTE) com a senha criptografada
  const hash = bcrypt.hashSync(senha, 10);
  const novo = db.prepare('INSERT INTO usuarios (nome, email, senha, cargo) VALUES (?, ?, ?, ?)')
    .run(nome, email, hash, 'CLIENTE');
  const usuarioId = Number(novo.lastInsertRowid);

  if (cliente) {
    db.prepare('UPDATE clientes SET usuario_id = ? WHERE id = ?').run(usuarioId, cliente.id);
  } else {
    db.prepare('INSERT INTO clientes (usuario_id, nome, cpf, telefone, email, data_nascimento) VALUES (?, ?, ?, ?, ?, ?)')
      .run(usuarioId, nome, cpf, telefone, email, nascimento);
  }

  // Já deixa a pessoa logada
  req.session.usuario = { id: usuarioId, nome: nome, email: email, cargo: 'CLIENTE' };
  res.status(201).json(req.session.usuario);
});

module.exports = router;
