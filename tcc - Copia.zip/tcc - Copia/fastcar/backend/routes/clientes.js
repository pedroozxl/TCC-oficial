// ============================================================
// routes/clientes.js  -  CRUD de clientes (uso dos funcionários)
// ============================================================
// GET    /clientes?busca=...   lista / pesquisa     (vendedor, gerente, administrador)
// POST   /clientes             cadastra             (vendedor, gerente, administrador)
// PUT    /clientes/:id         edita                (vendedor, gerente, administrador)
// DELETE /clientes/:id         exclui               (gerente, administrador)
const express = require('express');
const db = require('../database');
const { exigirCargo } = require('../protecao');
const { cpfValido, emailValido } = require('../validacoes');

const router = express.Router();
const funcionarios = exigirCargo('VENDEDOR', 'GERENTE', 'ADMINISTRADOR');
const soGerencia = exigirCargo('GERENTE', 'ADMINISTRADOR');

// Lê e confere os dados. Devolve { cliente } ou { erro }.
function lerCliente(corpo) {
  const cliente = {
    nome: String(corpo.nome || '').trim(),
    cpf: String(corpo.cpf || '').replace(/\D/g, ''),
    telefone: String(corpo.telefone || '').trim() || null,
    email: String(corpo.email || '').trim().toLowerCase() || null,
    data_nascimento: String(corpo.data_nascimento || '') || null
  };
  if (cliente.nome === '') {
    return { erro: 'O nome é obrigatório.' };
  }
  if (!cpfValido(cliente.cpf)) {
    return { erro: 'CPF inválido.' };
  }
  if (cliente.email && !emailValido(cliente.email)) {
    return { erro: 'E-mail inválido.' };
  }
  return { cliente: cliente };
}

// ----- LISTAR / PESQUISAR -----
router.get('/', funcionarios, (req, res) => {
  const busca = '%' + String(req.query.busca || '').trim() + '%';
  const clientes = db.prepare(`
    SELECT * FROM clientes
    WHERE nome LIKE ? OR cpf LIKE ? OR email LIKE ?
    ORDER BY nome`).all(busca, busca, busca);
  res.json(clientes);
});

// ----- CADASTRAR -----
router.post('/', funcionarios, (req, res) => {
  const lido = lerCliente(req.body);
  if (lido.erro) {
    return res.status(400).json({ erro: lido.erro });
  }
  const c = lido.cliente;

  if (db.prepare('SELECT id FROM clientes WHERE cpf = ?').get(c.cpf)) {
    return res.status(400).json({ erro: 'CPF já cadastrado.' });
  }

  const r = db.prepare('INSERT INTO clientes (nome, cpf, telefone, email, data_nascimento) VALUES (?, ?, ?, ?, ?)')
    .run(c.nome, c.cpf, c.telefone, c.email, c.data_nascimento);
  res.status(201).json({ id: Number(r.lastInsertRowid) });
});

// ----- EDITAR -----
router.put('/:id', funcionarios, (req, res) => {
  const atual = db.prepare('SELECT * FROM clientes WHERE id = ?').get(req.params.id);
  if (!atual) {
    return res.status(404).json({ erro: 'Cliente não encontrado.' });
  }
  const lido = lerCliente(req.body);
  if (lido.erro) {
    return res.status(400).json({ erro: lido.erro });
  }
  const c = lido.cliente;

  if (db.prepare('SELECT id FROM clientes WHERE cpf = ? AND id != ?').get(c.cpf, atual.id)) {
    return res.status(400).json({ erro: 'Outro cliente já usa este CPF.' });
  }

  db.prepare('UPDATE clientes SET nome = ?, cpf = ?, telefone = ?, email = ?, data_nascimento = ? WHERE id = ?')
    .run(c.nome, c.cpf, c.telefone, c.email, c.data_nascimento, atual.id);
  res.json({ mensagem: 'Cliente atualizado.' });
});

// ----- EXCLUIR -----
router.delete('/:id', soGerencia, (req, res) => {
  const cliente = db.prepare('SELECT * FROM clientes WHERE id = ?').get(req.params.id);
  if (!cliente) {
    return res.status(404).json({ erro: 'Cliente não encontrado.' });
  }
  const usado = db.prepare('SELECT COUNT(*) AS total FROM locacoes WHERE cliente_id = ?').get(cliente.id);
  if (usado.total > 0) {
    return res.status(400).json({ erro: 'Este cliente tem locações registradas e não pode ser excluído.' });
  }

  db.prepare('DELETE FROM clientes WHERE id = ?').run(cliente.id);
  // Se o cliente tinha login no site, apaga o login também
  if (cliente.usuario_id) {
    db.prepare('DELETE FROM usuarios WHERE id = ?').run(cliente.usuario_id);
  }
  res.json({ mensagem: 'Cliente excluído.' });
});

module.exports = router;
