// ============================================================
// routes/painel.js  -  números da tela inicial do painel
// ============================================================
const express = require('express');
const db = require('../database');
const { exigirCargo } = require('../protecao');

const router = express.Router();

// GET /painel/resumo
router.get('/resumo', exigirCargo('VENDEDOR', 'GERENTE', 'ADMINISTRADOR'), (req, res) => {
  const usuario = req.session.usuario;

  // Quantos veículos existem em cada status
  const veiculos = {
    total: db.prepare('SELECT COUNT(*) AS n FROM veiculos').get().n,
    disponiveis: db.prepare("SELECT COUNT(*) AS n FROM veiculos WHERE status = 'DISPONIVEL'").get().n,
    alugados: db.prepare("SELECT COUNT(*) AS n FROM veiculos WHERE status = 'ALUGADO'").get().n,
    manutencao: db.prepare("SELECT COUNT(*) AS n FROM veiculos WHERE status = 'MANUTENCAO'").get().n
  };

  // Locações: o vendedor vê só as dele; gerente e administrador veem todas
  let filtro = '';
  let valores = [];
  if (usuario.cargo === 'VENDEDOR') {
    filtro = ' AND vendedor_id = ?';
    valores = [usuario.id];
  }
  const contar = (status) => db.prepare('SELECT COUNT(*) AS n FROM locacoes WHERE status = ?' + filtro).get(status, ...valores).n;
  const receita = db.prepare("SELECT COALESCE(SUM(valor_total), 0) AS soma FROM locacoes WHERE status != 'CANCELADA'" + filtro).get(...valores).soma;

  res.json({
    veiculos: veiculos,
    locacoes: { ativas: contar('ATIVA'), finalizadas: contar('FINALIZADA'), canceladas: contar('CANCELADA'), receita: receita },
    clientes: db.prepare('SELECT COUNT(*) AS n FROM clientes').get().n,
    somenteMinhas: usuario.cargo === 'VENDEDOR',
    usuarios: usuario.cargo === 'ADMINISTRADOR' ? db.prepare("SELECT COUNT(*) AS n FROM usuarios WHERE cargo != 'CLIENTE'").get().n : null
  });
});

module.exports = router;
