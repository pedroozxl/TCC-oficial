// ============================================================
// routes/usuarios.js  -  CRUD dos funcionários (somente o administrador)
// ============================================================
// Os clientes do site não aparecem aqui: eles são gerenciados na tela de Clientes.
const express = require('express');
const bcrypt = require('bcryptjs');
const db = require('../database');
const { exigirCargo } = require('../protecao');
const { emailValido, senhaValida } = require('../validacoes');

const router = express.Router();
router.use(exigirCargo('ADMINISTRADOR')); // todas as rotas deste arquivo exigem administrador

const CARGOS = ['ADMINISTRADOR', 'GERENTE', 'VENDEDOR'];

// ----- LISTAR -----  (note que a senha NÃO é enviada)
router.get('/', (req, res) => {
  const usuarios = db.prepare("SELECT id, nome, email, cargo, ativo FROM usuarios WHERE cargo != 'CLIENTE' ORDER BY nome").all();
  res.json(usuarios);
});

// ----- CADASTRAR -----
router.post('/', (req, res) => {
  const nome = String(req.body.nome || '').trim();
  const email = String(req.body.email || '').trim().toLowerCase();
  const cargo = req.body.cargo;

  if (nome === '') {
    return res.status(400).json({ erro: 'O nome é obrigatório.' });
  }
  if (!emailValido(email)) {
    return res.status(400).json({ erro: 'E-mail inválido.' });
  }
  if (!CARGOS.includes(cargo)) {
    return res.status(400).json({ erro: 'Cargo inválido.' });
  }
  if (!senhaValida(req.body.senha)) {
    return res.status(400).json({ erro: 'A senha deve ter pelo menos 6 caracteres.' });
  }
  if (db.prepare('SELECT id FROM usuarios WHERE email = ?').get(email)) {
    return res.status(400).json({ erro: 'Já existe um usuário com este e-mail.' });
  }

  const hash = bcrypt.hashSync(req.body.senha, 10);
  const r = db.prepare('INSERT INTO usuarios (nome, email, senha, cargo) VALUES (?, ?, ?, ?)').run(nome, email, hash, cargo);
  res.status(201).json({ id: Number(r.lastInsertRowid) });
});

// ----- EDITAR -----  (a senha só muda se for enviada uma nova)
router.put('/:id', (req, res) => {
  const usuario = db.prepare("SELECT * FROM usuarios WHERE id = ? AND cargo != 'CLIENTE'").get(req.params.id);
  if (!usuario) {
    return res.status(404).json({ erro: 'Usuário não encontrado.' });
  }

  const nome = String(req.body.nome || '').trim();
  const email = String(req.body.email || '').trim().toLowerCase();
  const cargo = req.body.cargo;
  const ativo = Number(req.body.ativo) === 0 ? 0 : 1;

  if (nome === '' || !emailValido(email) || !CARGOS.includes(cargo)) {
    return res.status(400).json({ erro: 'Confira o nome, o e-mail e o cargo.' });
  }
  if (db.prepare('SELECT id FROM usuarios WHERE email = ? AND id != ?').get(email, usuario.id)) {
    return res.status(400).json({ erro: 'Já existe um usuário com este e-mail.' });
  }
  // Para não ficar sem administrador, ninguém muda o próprio cargo nem se desativa
  if (usuario.id === req.session.usuario.id && (cargo !== usuario.cargo || ativo === 0)) {
    return res.status(400).json({ erro: 'Você não pode alterar o seu próprio cargo nem se desativar.' });
  }

  let senha = usuario.senha;
  if (req.body.senha) {
    if (!senhaValida(req.body.senha)) {
      return res.status(400).json({ erro: 'A senha deve ter pelo menos 6 caracteres.' });
    }
    senha = bcrypt.hashSync(req.body.senha, 10);
  }

  db.prepare('UPDATE usuarios SET nome = ?, email = ?, senha = ?, cargo = ?, ativo = ? WHERE id = ?')
    .run(nome, email, senha, cargo, ativo, usuario.id);
  res.json({ mensagem: 'Usuário atualizado.' });
});

// ----- EXCLUIR -----
router.delete('/:id', (req, res) => {
  const usuario = db.prepare("SELECT * FROM usuarios WHERE id = ? AND cargo != 'CLIENTE'").get(req.params.id);
  if (!usuario) {
    return res.status(404).json({ erro: 'Usuário não encontrado.' });
  }
  if (usuario.id === req.session.usuario.id) {
    return res.status(400).json({ erro: 'Você não pode excluir a sua própria conta.' });
  }
  const usado = db.prepare('SELECT COUNT(*) AS total FROM locacoes WHERE vendedor_id = ?').get(usuario.id);
  if (usado.total > 0) {
    return res.status(400).json({ erro: 'Este usuário registrou locações. Em vez de excluir, desative-o (campo Ativo).' });
  }
  db.prepare('DELETE FROM usuarios WHERE id = ?').run(usuario.id);
  res.json({ mensagem: 'Usuário excluído.' });
});

module.exports = router;
