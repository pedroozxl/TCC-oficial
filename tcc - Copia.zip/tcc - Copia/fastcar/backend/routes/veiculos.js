// ============================================================
// routes/veiculos.js  -  CRUD de veículos
// ============================================================
// GET    /veiculos        lista (qualquer pessoa, o site usa)
// GET    /veiculos/:id    um veículo
// POST   /veiculos        cadastra   (gerente ou administrador)
// PUT    /veiculos/:id    edita      (gerente ou administrador)
// DELETE /veiculos/:id    exclui     (gerente ou administrador)
const express = require('express');
const db = require('../database');
const { exigirCargo } = require('../protecao');

const router = express.Router();
const soGerencia = exigirCargo('GERENTE', 'ADMINISTRADOR');

// Confere os dados do veículo. Devolve o texto do erro, ou null se estiver tudo certo.
function validarVeiculo(v) {
  if (!v.placa || !v.marca || !v.modelo) {
    return 'Informe placa, marca e modelo.';
  }
  if (!/^[A-Z]{3}[0-9][A-Z0-9][0-9]{2}$/.test(v.placa)) {
    return 'Placa inválida. Use o formato ABC1D23 ou ABC1234.';
  }
  if (!Number.isInteger(v.ano) || v.ano < 1980 || v.ano > 2100) {
    return 'Ano inválido.';
  }
  if (v.tipo !== 'CARRO' && v.tipo !== 'MOTO') {
    return 'O tipo deve ser CARRO ou MOTO.';
  }
  if (!(v.valor_diaria > 0)) {
    return 'O valor da diária deve ser maior que zero.';
  }
  if (v.preco_promocional !== null && !(v.preco_promocional > 0 && v.preco_promocional < v.valor_diaria)) {
    return 'O preço promocional deve ser maior que zero e menor que a diária.';
  }
  if (!['DISPONIVEL', 'ALUGADO', 'MANUTENCAO'].includes(v.status)) {
    return 'Status inválido.';
  }
  return null;
}

// Transforma o corpo da requisição (texto) em um objeto com os tipos certos
function lerVeiculo(corpo) {
  const numeroOuNulo = (x) => (x === '' || x === undefined || x === null ? null : Number(x));
  return {
    placa: String(corpo.placa || '').toUpperCase().replace(/[^A-Z0-9]/g, ''),
    marca: String(corpo.marca || '').trim(),
    modelo: String(corpo.modelo || '').trim(),
    ano: Number(corpo.ano),
    tipo: corpo.tipo,
    categoria: corpo.tipo === 'MOTO' ? null : (corpo.categoria || null),
    quilometragem: Number(corpo.quilometragem) || 0,
    combustivel: corpo.combustivel || null,
    cambio: corpo.cambio || null,
    portas: numeroOuNulo(corpo.portas),
    valor_diaria: Number(corpo.valor_diaria),
    preco_promocional: numeroOuNulo(corpo.preco_promocional),
    descricao: String(corpo.descricao || '').trim() || null,
    foto: String(corpo.foto || '').trim() || null,
    status: corpo.status || 'DISPONIVEL'
  };
}

// ----- LISTAR -----
router.get('/', (req, res) => {
  const veiculos = db.prepare('SELECT * FROM veiculos ORDER BY marca, modelo').all();
  res.json(veiculos);
});

// ----- BUSCAR UM -----
router.get('/:id', (req, res) => {
  const veiculo = db.prepare('SELECT * FROM veiculos WHERE id = ?').get(req.params.id);
  if (!veiculo) {
    return res.status(404).json({ erro: 'Veículo não encontrado.' });
  }
  res.json(veiculo);
});

// ----- CADASTRAR -----
router.post('/', soGerencia, (req, res) => {
  const v = lerVeiculo(req.body);

  const erro = validarVeiculo(v);
  if (erro) {
    return res.status(400).json({ erro: erro });
  }
  if (v.status === 'ALUGADO') {
    return res.status(400).json({ erro: 'O status ALUGADO é definido ao registrar uma locação.' });
  }
  if (db.prepare('SELECT id FROM veiculos WHERE placa = ?').get(v.placa)) {
    return res.status(400).json({ erro: 'Já existe um veículo com esta placa.' });
  }

  const r = db.prepare(`
    INSERT INTO veiculos (placa, marca, modelo, ano, tipo, categoria, quilometragem, combustivel, cambio,
                          portas, valor_diaria, preco_promocional, descricao, foto, status)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
    .run(v.placa, v.marca, v.modelo, v.ano, v.tipo, v.categoria, v.quilometragem, v.combustivel, v.cambio,
         v.portas, v.valor_diaria, v.preco_promocional, v.descricao, v.foto, v.status);

  res.status(201).json({ id: Number(r.lastInsertRowid) });
});

// ----- EDITAR -----
router.put('/:id', soGerencia, (req, res) => {
  const atual = db.prepare('SELECT * FROM veiculos WHERE id = ?').get(req.params.id);
  if (!atual) {
    return res.status(404).json({ erro: 'Veículo não encontrado.' });
  }

  const v = lerVeiculo(req.body);
  const erro = validarVeiculo(v);
  if (erro) {
    return res.status(400).json({ erro: erro });
  }
  if (db.prepare('SELECT id FROM veiculos WHERE placa = ? AND id != ?').get(v.placa, atual.id)) {
    return res.status(400).json({ erro: 'Já existe outro veículo com esta placa.' });
  }
  // Veículo alugado só volta a ficar disponível finalizando a locação
  if (atual.status === 'ALUGADO' && v.status !== 'ALUGADO') {
    return res.status(400).json({ erro: 'Veículo alugado: finalize a locação para liberá-lo.' });
  }
  if (atual.status !== 'ALUGADO' && v.status === 'ALUGADO') {
    return res.status(400).json({ erro: 'O status ALUGADO é definido ao registrar uma locação.' });
  }

  db.prepare(`
    UPDATE veiculos SET placa = ?, marca = ?, modelo = ?, ano = ?, tipo = ?, categoria = ?, quilometragem = ?,
           combustivel = ?, cambio = ?, portas = ?, valor_diaria = ?, preco_promocional = ?, descricao = ?,
           foto = ?, status = ?
    WHERE id = ?`)
    .run(v.placa, v.marca, v.modelo, v.ano, v.tipo, v.categoria, v.quilometragem, v.combustivel, v.cambio,
         v.portas, v.valor_diaria, v.preco_promocional, v.descricao, v.foto, v.status, atual.id);

  res.json({ mensagem: 'Veículo atualizado.' });
});

// ----- EXCLUIR -----
router.delete('/:id', soGerencia, (req, res) => {
  const veiculo = db.prepare('SELECT * FROM veiculos WHERE id = ?').get(req.params.id);
  if (!veiculo) {
    return res.status(404).json({ erro: 'Veículo não encontrado.' });
  }
  // Não pode excluir se já teve locações (o histórico precisa continuar existindo)
  const usado = db.prepare('SELECT COUNT(*) AS total FROM locacoes WHERE veiculo_id = ?').get(veiculo.id);
  if (usado.total > 0) {
    return res.status(400).json({ erro: 'Este veículo tem locações registradas e não pode ser excluído. Coloque-o em MANUTENCAO.' });
  }
  db.prepare('DELETE FROM veiculos WHERE id = ?').run(veiculo.id);
  res.json({ mensagem: 'Veículo excluído.' });
});

module.exports = router;
