// ============================================================
// dados-exemplo.js  -  OPCIONAL: preenche o banco com dados de demonstração
// ============================================================
// Nunca roda sozinho. Para usar:  npm run exemplo
// Só funciona se ainda não existir nenhum veículo cadastrado.
const db = require('./database');

if (db.prepare('SELECT COUNT(*) AS n FROM veiculos').get().n > 0) {
  console.log('O banco já tem veículos. Nada foi alterado.');
  process.exit(0);
}

// [placa, marca, modelo, ano, categoria, diária, preço promocional (ou null)]
const veiculos = [
  ['FST0A00', 'Fiat', 'Fastback', 2025, 'SUV', 189, null], ['FST0B01', 'Volkswagen', 'T-Cross', 2024, 'SUV', 199, null],
  ['FST0C02', 'Chevrolet', 'Tracker', 2025, 'SUV', 209, null], ['FST0D03', 'Hyundai', 'Creta', 2024, 'SUV', 195, null],
  ['FST0E04', 'Honda', 'HR-V', 2025, 'SUV', 219, null], ['FST0F05', 'Volkswagen', 'Nivus', 2024, 'SUV', 179, null],
  ['FST0G06', 'Toyota', 'Yaris Cross', 2025, 'SUV', 189, null], ['FST0H07', 'Renault', 'Kardian', 2024, 'SUV', 169, null],
  ['FST0I08', 'Fiat', 'Pulse', 2025, 'SUV', 175, null], ['FST0J09', 'Nissan', 'Kicks', 2024, 'SUV', 185, null],
  ['FST0K10', 'Hyundai', 'HB20S', 2025, 'SEDAN', 129, null], ['FST0L11', 'Chevrolet', 'Onix Plus', 2024, 'SEDAN', 125, null],
  ['FST0M12', 'Volkswagen', 'Virtus', 2025, 'SEDAN', 135, null], ['FST0N13', 'Fiat', 'Cronos', 2024, 'SEDAN', 119, null],
  ['FST0O14', 'Honda', 'City', 2025, 'SEDAN', 149, null], ['FST0P15', 'Nissan', 'Versa', 2024, 'SEDAN', 139, null],
  ['FST0Q16', 'Toyota', 'Corolla', 2025, 'SEDAN', 189, null], ['FST0R17', 'Honda', 'Civic', 2024, 'SEDAN', 199, null],
  ['FST0S18', 'BYD', 'King (híbrido)', 2025, 'SEDAN', 179, null], ['FST0T19', 'Renault', 'Logan', 2024, 'SEDAN', 109, null],
  ['FST0U20', 'Peugeot', '301', 2025, 'SEDAN', 115, null], ['FST0V21', 'Chery', 'Arrizo 6', 2024, 'SEDAN', 145, null],
  ['FST0W22', 'Volkswagen', 'Polo', 2025, 'HATCH', 99, 85], ['FST0X23', 'Hyundai', 'HB20', 2024, 'HATCH', 95, 82],
  ['FST0Y24', 'Chevrolet', 'Onix', 2025, 'HATCH', 89, null], ['FST0Z25', 'Fiat', 'Argo', 2024, 'HATCH', 92, null],
  ['FST1A26', 'Peugeot', '208', 2025, 'HATCH', 105, null], ['FST1B27', 'Renault', 'Kardian', 2024, 'HATCH', 99, null],
  ['FST1C28', 'Fiat', 'Mobi', 2025, 'HATCH', 79, 69], ['FST1D29', 'Renault', 'Kwid', 2024, 'HATCH', 75, null],
  ['FST1E30', 'Citroën', 'C3', 2025, 'HATCH', 89, null], ['FST1F31', 'Toyota', 'Yaris HB', 2024, 'HATCH', 109, null],
  ['FST1G32', 'BYD', 'Dolphin', 2025, 'ELETRICO', 219, null], ['FST1H33', 'Renault', 'Kwid E-Tech', 2024, 'ELETRICO', 179, null]
];

for (const v of veiculos) {
  db.prepare(`INSERT INTO veiculos (placa, marca, modelo, ano, tipo, categoria, valor_diaria, preco_promocional)
              VALUES (?, ?, ?, ?, 'CARRO', ?, ?, ?)`).run(v[0], v[1], v[2], v[3], v[4], v[5], v[6]);
}

// CPFs de exemplo (válidos)
const clientes = [
  ['Pedro Henrique', '52998224725', '(45) 99999-1111', 'pedro@email.com', '2000-05-10'],
  ['Maria Silva', '11144477735', '(45) 99999-2222', 'maria@email.com', '1995-08-21'],
  ['João Souza', '12345678909', '(45) 99999-3333', 'joao@email.com', '1988-12-02']
];
for (const c of clientes) {
  db.prepare('INSERT INTO clientes (nome, cpf, telefone, email, data_nascimento) VALUES (?, ?, ?, ?, ?)').run(...c);
}

console.log('Dados de exemplo carregados: ' + veiculos.length + ' veículos e ' + clientes.length + ' clientes.');
