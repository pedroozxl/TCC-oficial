// ============================================================
// protecao.js  -  proteção das rotas (login e cargo)
// ============================================================
// Depois do login, o servidor guarda os dados da pessoa em req.session.usuario.
// Estas duas funções são colocadas ANTES das rotas que precisam de proteção.

// Só deixa passar quem está logado
function exigirLogin(req, res, next) {
  if (!req.session.usuario) {
    return res.status(401).json({ erro: 'Faça login para continuar.' });
  }
  next(); // pode seguir para a rota
}

// Só deixa passar quem tem um dos cargos informados.
// Exemplo de uso:  exigirCargo('GERENTE', 'ADMINISTRADOR')
function exigirCargo(...cargos) {
  return function (req, res, next) {
    if (!req.session.usuario) {
      return res.status(401).json({ erro: 'Faça login para continuar.' });
    }
    if (!cargos.includes(req.session.usuario.cargo)) {
      return res.status(403).json({ erro: 'Você não tem permissão para isso.' });
    }
    next();
  };
}

module.exports = { exigirLogin, exigirCargo };
