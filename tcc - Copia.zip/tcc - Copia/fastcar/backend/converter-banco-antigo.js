// ============================================================
// converter-banco-antigo.js  -  traz os dados do banco da versão anterior
// ============================================================
// Quando o servidor encontra um banco no formato antigo, ele o guarda em database/backups/.
// Este programa lê esse backup (sem alterá-lo) e copia os dados para o banco novo.
//
// Uso:  npm run converter
//       (ou: npm run converter -- database/backups/NOME-DO-ARQUIVO.db)
const fs = require('fs');
const path = require('path');
const { DatabaseSync } = require('node:sqlite');
const db = require('./database'); // banco NOVO

// Descobre qual arquivo antigo usar: o informado ou o mais recente da pasta backups
const pastaBackups = path.join(__dirname, 'database', 'backups');
let arquivoAntigo = process.argv[2];
if (!arquivoAntigo) {
  const lista = fs.readdirSync(pastaBackups).filter((n) => n.startsWith('fastcar-antigo-')).sort();
  if (lista.length === 0) {
    console.log('Nenhum banco antigo encontrado em database/backups/.');
    process.exit(0);
  }
  arquivoAntigo = path.join(pastaBackups, lista[lista.length - 1]);
}
console.log('Lendo: ' + arquivoAntigo);
const antigo = new DatabaseSync(arquivoAntigo, { readOnly: true });

// Fotos antigas ficavam em backend/uploads/veiculos; agora ficam em frontend/img/veiculos
const pastaFotosAntigas = path.join(__dirname, 'uploads', 'veiculos');
const pastaFotosNovas = path.join(__dirname, '..', 'frontend', 'img', 'veiculos');
fs.mkdirSync(pastaFotosNovas, { recursive: true });

const contagem = { usuarios: 0, clientes: 0, veiculos: 0, locacoes: 0 };

// 1) Funcionários (os clientes com login são tratados no passo 2)
for (const u of antigo.prepare('SELECT * FROM usuarios').all()) {
  if (db.prepare('SELECT id FROM usuarios WHERE email = ?').get(u.email)) {
    continue; // já existe (por exemplo, o administrador criado automaticamente)
  }
  db.prepare('INSERT INTO usuarios (nome, email, senha, cargo, ativo) VALUES (?, ?, ?, ?, ?)')
    .run(u.nome, u.email, u.senha_hash, u.cargo, u.ativo);
  contagem.usuarios++;
}

// 2) Clientes (se tinham senha de acesso ao site, ganham um usuário com cargo CLIENTE)
const mapaClientes = {}; // id antigo -> id novo
for (const c of antigo.prepare('SELECT * FROM clientes').all()) {
  const jaExiste = db.prepare('SELECT id FROM clientes WHERE cpf = ?').get(c.cpf);
  if (jaExiste) {
    mapaClientes[c.id] = jaExiste.id;
    continue;
  }
  let usuarioId = null;
  if (c.senha_hash && c.email && !db.prepare('SELECT id FROM usuarios WHERE email = ?').get(c.email)) {
    usuarioId = Number(db.prepare('INSERT INTO usuarios (nome, email, senha, cargo, ativo) VALUES (?, ?, ?, ?, ?)')
      .run(c.nome, c.email, c.senha_hash, 'CLIENTE', c.ativo).lastInsertRowid);
  }
  const r = db.prepare('INSERT INTO clientes (usuario_id, nome, cpf, telefone, email, data_nascimento) VALUES (?, ?, ?, ?, ?, ?)')
    .run(usuarioId, c.nome, c.cpf, c.telefone, c.email, c.data_nascimento);
  mapaClientes[c.id] = Number(r.lastInsertRowid);
  contagem.clientes++;
}

// 3) Veículos (os status RESERVADO e INDISPONIVEL viram MANUTENCAO, pois o sistema novo tem só 3 status)
const mapaVeiculos = {};
for (const v of antigo.prepare('SELECT * FROM veiculos').all()) {
  const jaExiste = db.prepare('SELECT id FROM veiculos WHERE placa = ?').get(v.placa);
  if (jaExiste) {
    mapaVeiculos[v.id] = jaExiste.id;
    continue;
  }
  let foto = v.foto;
  if (foto && foto.startsWith('uploads/veiculos/')) {
    const nomeArquivo = path.basename(foto);
    const origem = path.join(pastaFotosAntigas, nomeArquivo);
    if (fs.existsSync(origem)) {
      fs.copyFileSync(origem, path.join(pastaFotosNovas, nomeArquivo));
      foto = 'img/veiculos/' + nomeArquivo;
    }
  }
  const status = ['DISPONIVEL', 'ALUGADO'].includes(v.status) ? v.status : 'MANUTENCAO';
  const r = db.prepare(`INSERT INTO veiculos (placa, marca, modelo, ano, tipo, categoria, quilometragem, combustivel, cambio,
                        portas, valor_diaria, descricao, foto, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
    .run(v.placa, v.marca, v.modelo, v.ano, v.tipo, v.categoria, v.quilometragem || 0, v.combustivel, v.cambio,
         v.portas, v.valor_diaria, v.descricao, foto, status);
  mapaVeiculos[v.id] = Number(r.lastInsertRowid);
  contagem.veiculos++;
}

// 4) Locações (o vendedor é procurado pelo e-mail, porque os números de id podem ter mudado)
for (const l of antigo.prepare('SELECT * FROM locacoes').all()) {
  let vendedorId = null;
  if (l.vendedor_id) {
    const vendedor = antigo.prepare('SELECT email FROM usuarios WHERE id = ?').get(l.vendedor_id);
    const novo = vendedor && db.prepare('SELECT id FROM usuarios WHERE email = ?').get(vendedor.email);
    vendedorId = novo ? novo.id : null;
  }
  if (!mapaClientes[l.cliente_id] || !mapaVeiculos[l.veiculo_id]) {
    continue;
  }
  db.prepare(`INSERT INTO locacoes (cliente_id, veiculo_id, vendedor_id, data_inicio, data_fim, valor_diaria, valor_total, status)
              VALUES (?, ?, ?, ?, ?, ?, ?, ?)`)
    .run(mapaClientes[l.cliente_id], mapaVeiculos[l.veiculo_id], vendedorId, l.data_inicio, l.data_fim,
         l.valor_diaria, l.valor_total, l.status);
  contagem.locacoes++;
}

console.log('Dados copiados: ' + contagem.usuarios + ' usuários, ' + contagem.clientes + ' clientes, '
  + contagem.veiculos + ' veículos, ' + contagem.locacoes + ' locações.');
console.log('O arquivo antigo continua guardado, sem alterações.');
