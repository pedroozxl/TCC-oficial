// ============================================================
// server.js  -  arquivo principal: liga o servidor do FastCar
// ============================================================
// Para ligar:  npm start   e abrir  http://localhost:3000
const path = require('path');
const express = require('express');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const db = require('./database');

const app = express();
const PORTA = process.env.PORT || 3000;

// Permite receber dados em JSON (enviados pelo fetch do frontend)
app.use(express.json());

// Sessão: é assim que o servidor "lembra" quem fez login (usa um cookie no navegador)
app.use(session({
  secret: process.env.SESSION_SECRET || 'fastcar-tcc-segredo',
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'lax', maxAge: 8 * 60 * 60 * 1000 } // vale por 8 horas
}));

// Rotas da API (cada arquivo cuida de um assunto)
app.use('/auth', require('./routes/auth'));
app.use('/veiculos', require('./routes/veiculos'));
app.use('/clientes', require('./routes/clientes'));
app.use('/locacoes', require('./routes/locacoes'));
app.use('/usuarios', require('./routes/usuarios'));
app.use('/painel', require('./routes/painel'));

// O próprio servidor entrega as páginas do site (pasta frontend)
app.use(express.static(path.join(__dirname, '..', 'frontend')));
app.get('/', (req, res) => res.redirect('/html/index.html'));

// Rota que não existe
app.use((req, res) => {
  res.status(404).json({ erro: 'Rota não encontrada.' });
});

// Qualquer erro inesperado cai aqui
app.use((erro, req, res, next) => {
  console.error(erro);
  res.status(500).json({ erro: 'Erro interno do servidor.' });
});

// Primeiro acesso: se não existir nenhum administrador, cria um padrão
function criarAdministradorInicial() {
  const existe = db.prepare("SELECT id FROM usuarios WHERE cargo = 'ADMINISTRADOR'").get();
  if (!existe) {
    const hash = bcrypt.hashSync('admin123', 10);
    db.prepare('INSERT INTO usuarios (nome, email, senha, cargo) VALUES (?, ?, ?, ?)')
      .run('Administrador', 'admin@fastcar.com', hash, 'ADMINISTRADOR');
    console.log('Administrador criado -> e-mail: admin@fastcar.com | senha: admin123 (troque depois de entrar)');
  }
}
criarAdministradorInicial();

app.listen(PORTA, () => {
  console.log('FastCar rodando em http://localhost:' + PORTA);
});
