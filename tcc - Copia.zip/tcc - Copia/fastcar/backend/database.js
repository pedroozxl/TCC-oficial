// ============================================================
// database.js  -  conexão com o banco de dados SQLite
// ============================================================
// O SQLite guarda tudo em UM arquivo (database/fastcar.db).
// Usamos o módulo "node:sqlite", que já vem dentro do Node.js (22.13 ou mais novo),
// por isso não precisa instalar nenhum programa de banco de dados.
//
// Como usar nas rotas:
//   db.prepare("SELECT * FROM veiculos WHERE id = ?").get(5)       -> devolve 1 registro
//   db.prepare("SELECT * FROM veiculos").all()                      -> devolve uma lista
//   db.prepare("INSERT INTO ... VALUES (?, ?)").run(a, b)           -> executa (INSERT/UPDATE/DELETE)
// Os pontos de interrogação (?) são preenchidos com os valores, o que evita SQL Injection.

const fs = require('fs');
const path = require('path');
const { DatabaseSync } = require('node:sqlite');

const pastaBanco = path.join(__dirname, 'database');
const arquivoBanco = path.join(pastaBanco, 'fastcar.db');
const pastaBackups = path.join(pastaBanco, 'backups');
fs.mkdirSync(pastaBackups, { recursive: true });

// ----- Banco da versão anterior (mais complexa) -----
// Se já existir um fastcar.db no formato antigo, ele NÃO é apagado:
// é movido para a pasta backups e um banco novo é criado.
// Depois, o comando "npm run converter" traz os dados antigos para o banco novo.
function guardarBancoAntigoSeExistir() {
  if (!fs.existsSync(arquivoBanco)) {
    return;
  }
  const teste = new DatabaseSync(arquivoBanco);
  const antigo = teste.prepare("SELECT name FROM sqlite_master WHERE name = 'sessoes'").get();
  teste.close();
  if (antigo) {
    const nome = 'fastcar-antigo-' + new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-') + '.db';
    fs.renameSync(arquivoBanco, path.join(pastaBackups, nome));
    for (const extra of ['-wal', '-shm']) {
      if (fs.existsSync(arquivoBanco + extra)) {
        fs.unlinkSync(arquivoBanco + extra);
      }
    }
    console.log('Banco antigo guardado em database/backups/' + nome);
    console.log('Para trazer os dados dele para o banco novo, rode:  npm run converter');
  }
}

guardarBancoAntigoSeExistir();

const db = new DatabaseSync(arquivoBanco);
db.exec('PRAGMA foreign_keys = ON'); // faz o banco respeitar as chaves estrangeiras

// ----- Criação das tabelas (só cria se ainda não existirem) -----
db.exec(`
  CREATE TABLE IF NOT EXISTS usuarios (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    senha TEXT NOT NULL,                -- senha guardada criptografada (hash)
    cargo TEXT NOT NULL,                -- ADMINISTRADOR, GERENTE, VENDEDOR ou CLIENTE
    ativo INTEGER NOT NULL DEFAULT 1    -- 1 = pode entrar, 0 = bloqueado
  );

  CREATE TABLE IF NOT EXISTS clientes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    usuario_id INTEGER,                 -- preenchido só se o cliente tem login no site
    nome TEXT NOT NULL,
    cpf TEXT NOT NULL UNIQUE,
    telefone TEXT,
    email TEXT,
    data_nascimento TEXT,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
  );

  CREATE TABLE IF NOT EXISTS veiculos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    placa TEXT NOT NULL UNIQUE,
    marca TEXT NOT NULL,
    modelo TEXT NOT NULL,
    ano INTEGER NOT NULL,
    tipo TEXT NOT NULL,                 -- CARRO ou MOTO
    categoria TEXT,                     -- SUV, SEDAN, HATCH ou ELETRICO (vazio para moto)
    quilometragem INTEGER DEFAULT 0,
    combustivel TEXT,
    cambio TEXT,
    portas INTEGER,
    valor_diaria REAL NOT NULL,
    preco_promocional REAL,             -- se preenchido, é o preço da oferta
    descricao TEXT,
    foto TEXT,                          -- endereço da imagem (ex.: img/veiculos/uno.jpg ou um link)
    status TEXT NOT NULL DEFAULT 'DISPONIVEL'   -- DISPONIVEL, ALUGADO ou MANUTENCAO
  );

  CREATE TABLE IF NOT EXISTS locacoes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    cliente_id INTEGER NOT NULL,
    veiculo_id INTEGER NOT NULL,
    vendedor_id INTEGER,                -- quem registrou (vazio = o próprio cliente, pelo site)
    data_inicio TEXT NOT NULL,
    data_fim TEXT NOT NULL,
    valor_diaria REAL NOT NULL,
    valor_total REAL NOT NULL,
    status TEXT NOT NULL DEFAULT 'ATIVA',       -- ATIVA, FINALIZADA ou CANCELADA
    FOREIGN KEY (cliente_id) REFERENCES clientes(id),
    FOREIGN KEY (veiculo_id) REFERENCES veiculos(id),
    FOREIGN KEY (vendedor_id) REFERENCES usuarios(id)
  );
`);

module.exports = db;
module.exports.arquivoBanco = arquivoBanco;
