# FastCar — Sistema de locação de veículos (TCC)

Site para clientes alugarem carros e motos + painel para os funcionários (vendedor, gerente e administrador).

**Tecnologias:** HTML, CSS e JavaScript puro (frontend) · Node.js + Express (backend) · SQLite (banco de dados).
O banco é só um arquivo (`backend/database/fastcar.db`): **não precisa instalar nenhum servidor de banco de dados.**

---

## Como instalar e rodar no Windows 10/11

1. Instale o **Node.js versão 22.13 ou mais nova** (baixe a versão "LTS" em https://nodejs.org). Para conferir, abra o PowerShell e digite `node -v`.
2. Abra o PowerShell **dentro da pasta `backend`** do projeto e rode, um comando de cada vez:

```powershell
npm install
npm start
```

3. Abra o navegador em **http://localhost:3000**.

Para desligar o servidor, volte ao PowerShell e aperte `Ctrl + C`.
Nas próximas vezes, basta rodar `npm start` (o `npm install` é só na primeira vez).

### Primeiro acesso (administrador)

Na primeira vez que o servidor liga, ele cria um administrador:

| E-mail | Senha |
|---|---|
| `admin@fastcar.com` | `admin123` |

Entre pela tela **Login** do site (`http://localhost:3000/html/login.html`). Funcionários são levados ao **painel**; clientes voltam ao site.
Depois de entrar, abra **Usuários**, edite o administrador e **troque a senha**. É por essa mesma tela que o administrador cadastra gerentes e vendedores.

### Dados de exemplo (opcional)

O banco começa vazio. Para ver o site cheio (34 veículos e 3 clientes de exemplo), rode uma vez: `npm run exemplo`.
Você também pode cadastrar tudo à mão, em **Painel → Veículos**.

### Vinha da versão anterior do FastCar?

Ao ligar o servidor, se existir um banco no formato antigo, ele **não é apagado**: é guardado em `backend/database/backups/` e um banco novo é criado. Para trazer os dados antigos (usuários, clientes, veículos, fotos e locações) para o banco novo, rode:

```powershell
npm run converter
```

---

## Quem pode fazer o quê

| Função | Cliente | Vendedor | Gerente | Administrador |
|---|:-:|:-:|:-:|:-:|
| Ver veículos e ofertas no site | ✔ | ✔ | ✔ | ✔ |
| Criar conta, reservar e ver as próprias reservas | ✔ | | | |
| Entrar no painel (resumo) | | ✔ | ✔ | ✔ |
| Consultar veículos | | ✔ | ✔ | ✔ |
| Cadastrar e editar clientes | | ✔ | ✔ | ✔ |
| Registrar e finalizar locações | | ✔ (só as dele) | ✔ (todas) | ✔ (todas) |
| Cancelar locações | | | ✔ | ✔ |
| Cadastrar, editar e excluir veículos / definir ofertas | | | ✔ | ✔ |
| Excluir clientes | | | ✔ | ✔ |
| Cadastrar, editar e excluir funcionários | | | | ✔ |

As permissões são conferidas **no servidor** (arquivo `protecao.js`), não só escondidas na tela.

---

## Estrutura do projeto

```text
fastcar/
├── backend/
│   ├── server.js                  liga o servidor, a sessão (login) e as rotas
│   ├── database.js                abre o SQLite e cria as tabelas
│   ├── protecao.js                exigirLogin e exigirCargo (proteção das rotas)
│   ├── validacoes.js              CPF, e-mail, senha, datas
│   ├── routes/
│   │   ├── auth.js                login, logout e cadastro do cliente
│   │   ├── veiculos.js            CRUD de veículos
│   │   ├── clientes.js            CRUD de clientes
│   │   ├── locacoes.js            registrar, finalizar e cancelar locações
│   │   ├── usuarios.js            CRUD de funcionários
│   │   └── painel.js              números do resumo
│   ├── dados-exemplo.js           (opcional) veículos e clientes de exemplo
│   ├── converter-banco-antigo.js  (opcional) traz dados da versão anterior
│   ├── package.json               dependências: express, express-session, bcryptjs
│   └── database/fastcar.db        o banco (criado sozinho)
└── frontend/
    ├── html/    páginas do site (index, veiculos, ofertas, reserva, login, cadastro...)
    │            e do painel (painel.html, painel-veiculos.html, painel-clientes.html,
    │            painel-locacoes.html, painel-usuarios.html)
    ├── css/     estilos (global.css, painel.css...)
    ├── js/      scripts (global.js, auth.js, painel-comum.js, painel-veiculos.js...)
    └── img/veiculos/   fotos dos veículos
```

## Como as peças conversam

```text
Navegador (HTML + JavaScript)  --fetch()-->  Rota do Express (routes/*.js)  --SQL-->  SQLite
```

Exemplo, ao clicar em "Salvar" no cadastro de veículo:

1. `painel-veiculos.js` junta os campos e chama `chamarApi("/veiculos", "POST", dados)` (que usa o `fetch`).
2. `routes/veiculos.js` recebe em `router.post("/")`, confere o cargo (`soGerencia`), valida os dados e executa `INSERT INTO veiculos ...`.
3. O servidor responde em JSON e a tela mostra a mensagem e atualiza a tabela.

No código do backend, o acesso ao banco é sempre assim:

```js
db.prepare("SELECT * FROM veiculos WHERE id = ?").get(5);     // 1 registro
db.prepare("SELECT * FROM veiculos").all();                    // vários registros
db.prepare("DELETE FROM veiculos WHERE id = ?").run(5);        // INSERT / UPDATE / DELETE
```

## Banco de dados (4 tabelas)

- **usuarios** — `id, nome, email, senha (criptografada), cargo, ativo`. Cargos: ADMINISTRADOR, GERENTE, VENDEDOR, CLIENTE.
- **clientes** — `id, usuario_id, nome, cpf, telefone, email, data_nascimento`. `usuario_id` só existe se o cliente criou login no site.
- **veiculos** — `id, placa, marca, modelo, ano, tipo, categoria, quilometragem, combustivel, cambio, portas, valor_diaria, preco_promocional, descricao, foto, status`. Status: DISPONIVEL, ALUGADO, MANUTENCAO.
- **locacoes** — `id, cliente_id, veiculo_id, vendedor_id, data_inicio, data_fim, valor_diaria, valor_total, status`. Status: ATIVA, FINALIZADA, CANCELADA. As chaves estrangeiras ligam a locação ao cliente, ao veículo e ao funcionário.

Regras: ao registrar uma locação, o veículo vira ALUGADO; ao finalizar ou cancelar, volta a DISPONIVEL. Veículo, cliente ou funcionário que já tem locações não pode ser excluído (o histórico é preservado). Se o veículo tem **preço promocional**, a locação é cobrada por ele e o site mostra a oferta.

## Rotas da API

| Rota | O que faz | Quem |
|---|---|---|
| `POST /auth/login`, `/auth/logout`, `/auth/cadastro` · `GET /auth/eu` | login, sair, criar conta, quem está logado | todos |
| `GET /veiculos`, `/veiculos/:id` | consultar | todos |
| `POST/PUT/DELETE /veiculos` | cadastrar, editar, excluir | gerente, admin |
| `GET/POST/PUT /clientes` · `DELETE /clientes/:id` | clientes | vendedor+ · gerente+ |
| `GET /locacoes` · `GET /locacoes/minhas` | lista (funcionários) · as do cliente logado | |
| `POST /locacoes` | registrar | cliente (para si) ou funcionário |
| `PUT /locacoes/:id/finalizar` · `/cancelar` | encerrar | vendedor+ · gerente+ |
| `GET/POST/PUT/DELETE /usuarios` | funcionários | administrador |
| `GET /painel/resumo` | números do resumo | funcionários |

## Fotos dos veículos

No cadastro do veículo, o campo **Foto** aceita um link da internet **ou** o caminho de uma imagem que você colocou em `frontend/img/veiculos/` (por exemplo `img/veiculos/uno.jpg`). Sem foto, o site usa a imagem padrão da categoria.

## Backup do banco

Com o servidor desligado, copie o arquivo `backend/database/fastcar.db` para um lugar seguro (e a pasta `frontend/img/veiculos/`, se tiver fotos). Para restaurar, coloque o arquivo de volta no mesmo lugar.

## Problemas comuns

- **`Cannot find module ...`**: o `npm install` não foi feito (ou não terminou). Rode-o dentro da pasta `backend`.
- **`EADDRINUSE`**: a porta 3000 já está em uso. Feche o outro programa ou rode `$env:PORT=3001; npm start` e abra `http://localhost:3001`.
- **Erro sobre `node:sqlite`**: o Node é antigo. Instale a versão LTS (22.13 ou mais nova).
- Abra sempre o site por `http://localhost:3000` (não clicando duas vezes nos arquivos `.html`), senão o login não funciona.
- Ao reiniciar o servidor, quem estava logado precisa entrar de novo (a sessão fica na memória). Os dados do banco **não** se perdem.

## O que foi simplificado nesta versão

- Backend: de 34 arquivos JavaScript (3.316 linhas) para 12 arquivos (cerca de 1.040 linhas), sem camadas de controllers/serviços/middlewares; cada rota faz sua consulta SQL direto.
- Dependências: de 10 para 3 (`express`, `express-session`, `bcryptjs`). O SQLite é o que já vem no Node.
- Removidos: auditoria, histórico de preços, movimentações de estoque, promoções com regras, relatórios PDF/Excel, recuperação de senha, upload de arquivos, proteção CSRF, limite de tentativas de login e migrações versionadas.
- Mantido: login/logout, 4 cargos, CRUD de veículos/clientes/usuários, locações, disponibilidade, ofertas, resumo e toda a identidade visual do site.
