// Dados fixos do site (não vêm do banco)

var SEGURO_DIARIA = 29;

// Categorias exibidas na tela de veículos.
// "chave" é o valor guardado no banco (coluna categoria; MOTO vem da coluna tipo).
// "imagem" é a classe CSS que define a foto do cartão.
var categorias = [
  { chave: "SUV", nome: "SUVs", icone: "car-front", imagem: "suv",
    detalhe: "SUV versátil · 5 lugares · Conforto para a estrada" },
  { chave: "SEDAN", nome: "Sedãs", icone: "car", imagem: "sedan",
    detalhe: "Sedã confortável · 5 lugares · Porta-malas amplo" },
  { chave: "HATCH", nome: "Hatchbacks", icone: "car", imagem: "hatch",
    detalhe: "Hatchback urbano · 5 lugares · Ágil e econômico" },
  { chave: "ELETRICO", nome: "Elétricos", icone: "zap", imagem: "electric",
    detalhe: "Mobilidade elétrica · silenciosa · eficiente" },
  { chave: "CARRO", nome: "Carros", icone: "car", imagem: "sedan",
    detalhe: "Carro · 5 lugares · Conforto no dia a dia" },
  { chave: "MOTO", nome: "Motocicletas", icone: "bike", imagem: "hatch",
    detalhe: "Motocicleta · ágil · econômica" }
];

// Veículos em destaque na Home e na página de Ofertas
var destaques = [
  { categoria: "Sedãs", nome: "Toyota Corolla" },
  { categoria: "SUVs", nome: "Hyundai Creta" },
  { categoria: "Hatchbacks", nome: "Volkswagen Polo" }
];

// Procura uma categoria pela chave. Se não achar, usa "Carros".
function buscarCategoria(chave) {
  for (var i = 0; i < categorias.length; i++) {
    if (categorias[i].chave === chave) {
      return categorias[i];
    }
  }
  return categorias[4];
}

// Procura uma categoria pelo nome (ex.: "SUVs"). Retorna null se não existir.
function buscarCategoriaPorNome(nome) {
  for (var i = 0; i < categorias.length; i++) {
    if (categorias[i].nome === nome) {
      return categorias[i];
    }
  }
  return null;
}

// Escolhe os veículos em destaque: primeiro os que estão em oferta (preço promocional cadastrado no painel);
// se não houver nenhum, usa a lista fixa "destaques" acima.
function escolherDestaques(veiculos) {
  var resultado = [];
  for (var i = 0; i < veiculos.length && resultado.length < 3; i++) {
    if (veiculos[i].emOferta && veiculos[i].disponivel) {
      resultado.push(veiculos[i]);
    }
  }
  if (resultado.length > 0) {
    return resultado;
  }
  for (var j = 0; j < destaques.length; j++) {
    var veiculo = acharVeiculo(veiculos, destaques[j].nome, destaques[j].categoria);
    if (veiculo !== null) {
      resultado.push(veiculo);
    }
  }
  return resultado;
}
