// Login e cadastro

document.addEventListener("DOMContentLoaded", function () {
  mostrarAviso();
  ligarMascaras();
  ligarLogin();
  ligarCadastro();
});

// Mostra ou esconde uma mensagem na tela
function mostrarMensagem(id, texto) {
  var elemento = document.getElementById(id);
  if (elemento === null) {
    return;
  }
  elemento.textContent = texto;
  if (texto === "") {
    elemento.classList.add("hidden-state");
  } else {
    elemento.classList.remove("hidden-state");
  }
}

// Aviso quando o usuário veio de uma tentativa de reserva
function mostrarAviso() {
  var aviso = document.getElementById("login-context");
  var veioDaReserva = new URLSearchParams(window.location.search).get("return");
  if (aviso !== null && veioDaReserva) {
    aviso.textContent = "Entre ou cadastre-se para continuar sua reserva.";
    aviso.classList.remove("hidden-state");
  }
}

// Formata CPF e telefone enquanto o usuário digita
function ligarMascaras() {
  var cpf = document.getElementById("signup-cpf");
  var telefone = document.getElementById("signup-phone");
  if (cpf !== null) {
    cpf.addEventListener("input", function () {
      cpf.value = formatarCPF(cpf.value);
    });
  }
  if (telefone !== null) {
    telefone.addEventListener("input", function () {
      telefone.value = formatarTelefone(telefone.value);
    });
  }
}

// Para onde ir depois de entrar: reserva (se escolheu veículo) ou início
function destinoDepoisDoLogin() {
  if (lerSelecao() !== null) {
    return "reserva.html";
  }
  return "index.html";
}

function ligarLogin() {
  var formulario = document.getElementById("login-form");
  if (formulario === null) {
    return;
  }
  formulario.addEventListener("submit", async function (evento) {
    evento.preventDefault();
    mostrarMensagem("login-message", "");

    var email = document.getElementById("login-email").value.trim().toLowerCase();
    var senha = document.getElementById("login-password").value;
    if (email === "" || senha === "") {
      mostrarMensagem("login-message", "Informe o e-mail e a senha.");
      return;
    }

    var botao = document.getElementById("login-submit");
    botao.disabled = true;
    try {
      var dados = await chamarApi("/auth/login", "POST", { email: email, senha: senha });
      // Cliente volta para a reserva/início; funcionário vai para o painel
      if (dados.cargo === "CLIENTE") {
        window.location.href = destinoDepoisDoLogin();
      } else {
        window.location.href = "painel.html";
      }
    } catch (erro) {
      mostrarMensagem("login-message", erro.message);
      botao.disabled = false;
    }
  });
}

function ligarCadastro() {
  var formulario = document.getElementById("signup-form");
  if (formulario === null) {
    return;
  }
  formulario.addEventListener("submit", cadastrar);
}

async function cadastrar(evento) {
  evento.preventDefault();
  mostrarMensagem("signup-message", "");

  var nome = document.getElementById("signup-name").value.trim();
  var telefone = document.getElementById("signup-phone").value.trim();
  var cpf = document.getElementById("signup-cpf").value.trim();
  var nascimento = document.getElementById("signup-birth").value;
  var email = document.getElementById("signup-email").value.trim().toLowerCase();
  var senha = document.getElementById("signup-password").value;
  var confirmacao = document.getElementById("signup-password-confirm").value;
  var cpfNumeros = cpf.replace(/\D/g, "");

  if (nome === "" || telefone === "" || cpf === "" || nascimento === "" || email === "" || senha === "") {
    mostrarMensagem("signup-message", "Preencha todos os campos para continuar.");
    return;
  }
  if (cpfNumeros.length !== 11) {
    mostrarMensagem("signup-message", "Informe um CPF com 11 dígitos.");
    return;
  }
  if (senha.length < 6) {
    mostrarMensagem("signup-message", "A senha deve ter pelo menos 6 caracteres.");
    return;
  }
  if (senha !== confirmacao) {
    mostrarMensagem("signup-message", "As senhas não coincidem.");
    return;
  }

  var botao = document.getElementById("signup-submit");
  botao.disabled = true;

  try {
    // O servidor cria o cliente no banco (a senha é guardada criptografada) e já faz o login
    var dados = await chamarApi("/auth/cadastro", "POST", {
      nome: nome,
      cpf: cpfNumeros,
      telefone: telefone,
      email: email,
      data_nascimento: nascimento,
      senha: senha
    });
    window.location.href = destinoDepoisDoLogin();
  } catch (erro) {
    mostrarMensagem("signup-message", erro.message);
    botao.disabled = false;
  }
}
