// Painel > Clientes: cadastrar, pesquisar, editar e excluir

var usuario = null;
var clientes = [];

document.addEventListener("DOMContentLoaded", async function () {
  usuario = await iniciarPainel(["VENDEDOR", "GERENTE", "ADMINISTRADOR"]);
  if (usuario === null) {
    return;
  }

  document.getElementById("form-cliente").addEventListener("submit", salvarCliente);

  // Formata CPF e telefone enquanto digita (funções do global.js)
  document.getElementById("cpf").addEventListener("input", function () {
    this.value = formatarCPF(this.value);
  });
  document.getElementById("telefone").addEventListener("input", function () {
    this.value = formatarTelefone(this.value);
  });

  carregarClientes();
});

// Busca no servidor (o texto da pesquisa vai na URL: /clientes?busca=...)
async function carregarClientes() {
  try {
    var busca = encodeURIComponent(valor("busca"));
    clientes = await chamarApi("/clientes?busca=" + busca);
    mostrarTabela();
  } catch (erro) {
    mostrarAviso(erro.message, true);
  }
}

function mostrarTabela() {
  var podeExcluir = usuario.cargo === "GERENTE" || usuario.cargo === "ADMINISTRADOR";
  var linhas = [];

  for (var i = 0; i < clientes.length; i++) {
    var c = clientes[i];
    var acoes = '<button class="btn btn-mini" onclick="editarCliente(' + c.id + ')">Editar</button>';
    if (podeExcluir) {
      acoes += '<button class="btn btn-mini btn-perigo" onclick="excluirCliente(' + c.id + ')">Excluir</button>';
    }
    var temLogin = "nao";
    var textoLogin = "Não";
    if (c.usuario_id) {
      temLogin = "sim";
      textoLogin = "Sim";
    }
    linhas.push(
      "<td><strong>" + escaparHtml(c.nome) + "</strong></td>" +
      "<td>" + formatarCPF(c.cpf) + "</td>" +
      "<td>" + escaparHtml(c.telefone || "") + "</td>" +
      "<td>" + escaparHtml(c.email || "") + "</td>" +
      '<td><span class="tag ' + temLogin + '">' + textoLogin + "</span></td>" +
      '<td class="acoes">' + acoes + "</td>"
    );
  }
  document.getElementById("tabela").innerHTML = montarTabela(["Nome", "CPF", "Telefone", "E-mail", "Login no site", "Ações"], linhas);
}

async function salvarCliente(evento) {
  evento.preventDefault();

  var dados = {
    nome: valor("nome"), cpf: valor("cpf"), telefone: valor("telefone"),
    email: valor("email"), data_nascimento: valor("nascimento")
  };

  var id = valor("cliente-id");
  try {
    if (id === "") {
      await chamarApi("/clientes", "POST", dados);
      mostrarAviso("Cliente cadastrado!");
    } else {
      await chamarApi("/clientes/" + id, "PUT", dados);
      mostrarAviso("Cliente atualizado!");
    }
    limparFormulario();
    carregarClientes();
  } catch (erro) {
    mostrarAviso(erro.message, true);
  }
}

function editarCliente(id) {
  for (var i = 0; i < clientes.length; i++) {
    if (clientes[i].id === id) {
      var c = clientes[i];
      document.getElementById("cliente-id").value = c.id;
      document.getElementById("nome").value = c.nome;
      document.getElementById("cpf").value = formatarCPF(c.cpf);
      document.getElementById("telefone").value = c.telefone || "";
      document.getElementById("email").value = c.email || "";
      document.getElementById("nascimento").value = c.data_nascimento || "";
      document.getElementById("titulo-formulario").textContent = "Editar cliente";
      window.scrollTo(0, 0);
    }
  }
}

function limparFormulario() {
  document.getElementById("form-cliente").reset();
  document.getElementById("cliente-id").value = "";
  document.getElementById("titulo-formulario").textContent = "Cadastrar cliente";
}

async function excluirCliente(id) {
  if (!confirm("Excluir este cliente?")) {
    return;
  }
  try {
    await chamarApi("/clientes/" + id, "DELETE");
    mostrarAviso("Cliente excluído.");
    carregarClientes();
  } catch (erro) {
    mostrarAviso(erro.message, true);
  }
}
