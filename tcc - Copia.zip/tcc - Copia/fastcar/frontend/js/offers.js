// Página de ofertas

document.addEventListener("DOMContentLoaded", mostrarOfertas);

async function mostrarOfertas() {
  var lista = document.getElementById("offers-list");
  if (lista === null) {
    return;
  }

  var veiculos;
  try {
    veiculos = await carregarVeiculos();
  } catch (erro) {
    lista.innerHTML = '<p class="form-message">' + escaparHtml(erro.message) + "</p>";
    return;
  }

  var escolhidos = escolherDestaques(veiculos);
  for (var i = 0; i < escolhidos.length; i++) {
    lista.appendChild(criarCartaoOferta(escolhidos[i], i));
  }
  atualizarIcones();
}

function criarCartaoOferta(veiculo, posicao) {
  var selo = "Condição especial";
  if (veiculo.emOferta) {
    selo = "Oferta";
  } else if (posicao === 0) {
    selo = "Destaque";
  }

  var cartao = document.createElement("a");
  cartao.href = "veiculos.html?categoria=" + encodeURIComponent(veiculo.categoria.nome);
  cartao.className = "offer-card";
  cartao.innerHTML =
    '<div class="offer-image ' + veiculo.categoria.imagem + '"></div>' +
    '<div class="offer-body">' +
      '<span class="pill pill-orange">' + selo + "</span>" +
      '<span class="offer-category">' + veiculo.categoria.nome + "</span>" +
      "<h2>" + escaparHtml(veiculo.nome) + "</h2>" +
      "<p>" + veiculo.categoria.detalhe + "</p>" +
      '<div class="offer-bottom"><strong>' + htmlPreco(veiculo) + "</strong>" +
        '<span>por dia <i data-lucide="arrow-up-right"></i></span></div>' +
    "</div>";
  aplicarFoto(cartao.querySelector(".offer-image"), veiculo);
  return cartao;
}
