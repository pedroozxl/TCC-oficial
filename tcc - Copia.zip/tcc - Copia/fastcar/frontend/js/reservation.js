// Página de reserva

var usuario = null;
var selecao = null;

document.addEventListener("DOMContentLoaded", iniciarReserva);

async function iniciarReserva() {
  // Precisa estar logado (a sessão vem do servidor)
  usuario = await carregarSessao();
  if (usuario === null) {
    window.location.href = "login.html?return=reserva";
    return;
  }

  // Precisa ter escolhido um veículo
  selecao = lerSelecao();
  if (selecao === null || !selecao.veiculoId) {
    document.getElementById("selected-vehicle").textContent = "Nenhum veículo selecionado";
    document.getElementById("selected-price").textContent = "Volte para a frota e escolha um veículo.";
    return;
  }

  document.getElementById("selected-vehicle").textContent = selecao.categoria + " · " + selecao.modelo;
  document.getElementById("selected-price").textContent = formatarMoeda(selecao.preco) + " por dia";
  document.getElementById("customer-name").value = usuario.nome;
  document.getElementById("customer-email").value = usuario.email;

  document.getElementById("rental-days").addEventListener("input", atualizarResumo);
  document.getElementById("insurance-toggle").addEventListener("change", atualizarResumo);
  document.getElementById("rental-form").addEventListener("submit", confirmarReserva);
  atualizarResumo();
}

// Calcula e mostra o resumo de valores. Devolve os números calculados.
function atualizarResumo() {
  var dias = Number(document.getElementById("rental-days").value);
  if (!dias || dias < 1) {
    dias = 1;
  }
  var comSeguro = document.getElementById("insurance-toggle").checked;

  var subtotal = selecao.preco * dias;
  var seguro = 0;
  if (comSeguro) {
    seguro = SEGURO_DIARIA * dias;
  }

  var textoDias = " dias";
  if (dias === 1) {
    textoDias = " dia";
  }
  document.getElementById("summary-daily-line").textContent = formatarMoeda(selecao.preco) + "/dia × " + dias + textoDias;
  document.getElementById("summary-subtotal").textContent = formatarMoeda(subtotal);
  document.getElementById("summary-insurance-line").textContent = "Seguro · " + formatarMoeda(SEGURO_DIARIA) + "/dia × " + dias;
  document.getElementById("summary-insurance-total").textContent = formatarMoeda(seguro);
  document.getElementById("summary-total").textContent = formatarMoeda(subtotal + seguro);

  var linhaSeguro = document.getElementById("summary-insurance-row");
  if (comSeguro) {
    linhaSeguro.classList.remove("hidden-state");
  } else {
    linhaSeguro.classList.add("hidden-state");
  }

  return { dias: dias, seguro: seguro };
}

function mostrarErro(texto) {
  var mensagem = document.getElementById("form-message");
  mensagem.textContent = texto;
  mensagem.classList.remove("hidden-state");
}

async function confirmarReserva(evento) {
  evento.preventDefault();
  document.getElementById("form-message").classList.add("hidden-state");

  var dataRetirada = document.getElementById("pickup-date").value;
  if (dataRetirada === "") {
    mostrarErro("Informe a data de retirada.");
    return;
  }

  var resumo = atualizarResumo();
  var botao = document.getElementById("submit-button");
  botao.disabled = true;

  try {
    // O backend identifica o cliente pela sessão, valida tudo e calcula o valor total
    var locacao = await chamarApi("/locacoes", "POST", {
      veiculo_id: selecao.veiculoId,
      data_inicio: dataRetirada,
      data_fim: somarDias(dataRetirada, resumo.dias)
    });

    limparSelecao();

    var texto = "Locação nº " + locacao.id + " registrada no banco de dados. " +
      "Valor das diárias calculado pelo servidor: " + formatarMoeda(locacao.valor_total) + ".";
    if (resumo.seguro > 0) {
      texto = texto + " O seguro opcional (" + formatarMoeda(resumo.seguro) + ") é apenas informativo neste protótipo.";
    }
    document.getElementById("success-text").textContent = texto;

    document.getElementById("rental-form").parentElement.classList.add("hidden-state");
    document.getElementById("success-state").classList.remove("hidden-state");
    atualizarIcones();
  } catch (erro) {
    mostrarErro(erro.message);
    botao.disabled = false;
  }
}
