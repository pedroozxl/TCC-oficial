// Tela inicial do painel: mostra os números do sistema

document.addEventListener("DOMContentLoaded", async function () {
  var usuario = await iniciarPainel(["VENDEDOR", "GERENTE", "ADMINISTRADOR"]);
  if (usuario === null) {
    return;
  }

  try {
    var r = await chamarApi("/painel/resumo");

    if (r.somenteMinhas) {
      document.getElementById("subtitulo").textContent = "Olá, " + usuario.nome + ". As locações abaixo são as que você registrou.";
    } else {
      document.getElementById("subtitulo").textContent = "Olá, " + usuario.nome + ". Estes são os números atuais do FastCar.";
    }

    var html = "";
    html += cartao("Veículos cadastrados", r.veiculos.total, true);
    html += cartao("Disponíveis", r.veiculos.disponiveis);
    html += cartao("Alugados", r.veiculos.alugados);
    html += cartao("Em manutenção", r.veiculos.manutencao);
    html += cartao("Locações ativas", r.locacoes.ativas);
    html += cartao("Locações finalizadas", r.locacoes.finalizadas);
    html += cartao("Locações canceladas", r.locacoes.canceladas);
    html += cartao("Valor das locações", formatarMoeda(r.locacoes.receita), true);
    html += cartao("Clientes", r.clientes);
    if (r.usuarios !== null) {
      html += cartao("Funcionários", r.usuarios);
    }
    document.getElementById("cartoes").innerHTML = html;
  } catch (erro) {
    mostrarAviso(erro.message, true);
  }
});

// Monta o HTML de um cartão com título e número
function cartao(titulo, numero, destaque) {
  var classe = "card-num";
  if (destaque) {
    classe = "card-num destaque";
  }
  return '<div class="' + classe + '"><span>' + titulo + "</span><strong>" + numero + "</strong></div>";
}
