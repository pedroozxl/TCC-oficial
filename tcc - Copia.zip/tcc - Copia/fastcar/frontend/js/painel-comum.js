// ============================================================
// painel-comum.js  -  usado por TODAS as páginas do painel
// ============================================================
// Cada página chama:  iniciarPainel(["GERENTE", "ADMINISTRADOR"])  com os cargos que podem vê-la.
// Esta função confere o login, desenha o menu lateral e devolve os dados do usuário.

// Páginas do menu e quais cargos podem abrir cada uma
var MENU = [
  { texto: "Resumo",   pagina: "painel.html",          cargos: ["VENDEDOR", "GERENTE", "ADMINISTRADOR"] },
  { texto: "Veículos", pagina: "painel-veiculos.html", cargos: ["VENDEDOR", "GERENTE", "ADMINISTRADOR"] },
  { texto: "Clientes", pagina: "painel-clientes.html", cargos: ["VENDEDOR", "GERENTE", "ADMINISTRADOR"] },
  { texto: "Locações", pagina: "painel-locacoes.html", cargos: ["VENDEDOR", "GERENTE", "ADMINISTRADOR"] },
  { texto: "Usuários", pagina: "painel-usuarios.html", cargos: ["ADMINISTRADOR"] }
];

var NOMES_CARGOS = { ADMINISTRADOR: "Administrador", GERENTE: "Gerente", VENDEDOR: "Vendedor" };

async function iniciarPainel(cargosPermitidos) {
  var usuario = await carregarSessao();

  // Sem login (ou cliente do site): volta para a tela de login
  if (usuario === null || usuario.cargo === "CLIENTE") {
    window.location.href = "login.html";
    return null;
  }
  // Logado, mas este cargo não pode ver esta página
  if (cargosPermitidos.indexOf(usuario.cargo) === -1) {
    window.location.href = "painel.html";
    return null;
  }

  desenharMenu(usuario);
  return usuario;
}

function desenharMenu(usuario) {
  var paginaAtual = window.location.pathname.split("/").pop();
  var links = "";
  for (var i = 0; i < MENU.length; i++) {
    if (MENU[i].cargos.indexOf(usuario.cargo) !== -1) {
      var classe = "";
      if (MENU[i].pagina === paginaAtual) {
        classe = ' class="active"';
      }
      links += '<a href="' + MENU[i].pagina + '"' + classe + ">" + MENU[i].texto + "</a>";
    }
  }

  document.getElementById("menu-lateral").innerHTML =
    '<a class="brand" href="index.html"><span class="brand-mark"><i data-lucide="move-right"></i></span>' +
    '<span class="brand-name" style="color:#fff">fast<span>car</span></span></a>' +
    '<div class="side-user"><strong>' + escaparHtml(usuario.nome) + '</strong>' +
    '<span class="pill pill-orange">' + NOMES_CARGOS[usuario.cargo] + "</span></div>" +
    '<nav class="side-menu">' + links + "</nav>" +
    '<div class="side-foot"><a class="side-link" href="index.html">Ver o site</a>' +
    '<button class="side-link" type="button" onclick="sair()">Sair</button></div>';

  // Botão do menu no celular
  document.getElementById("botao-menu").addEventListener("click", function () {
    document.getElementById("menu-lateral").classList.toggle("aberto");
  });
  atualizarIcones();
}

// Mensagem rápida no canto da tela (erro = true deixa vermelha)
function mostrarAviso(texto, erro) {
  var aviso = document.getElementById("aviso");
  aviso.textContent = texto;
  aviso.className = "toast";
  if (erro) {
    aviso.className = "toast erro";
  }
  setTimeout(function () {
    aviso.classList.add("hidden-state");
  }, 4000);
}

// Monta uma tabela HTML. colunas = títulos, linhas = lista de textos HTML já prontos.
function montarTabela(titulos, linhas) {
  if (linhas.length === 0) {
    return '<p class="vazio">Nenhum registro encontrado.</p>';
  }
  var html = '<div class="tabela-wrap"><table class="tabela"><thead><tr>';
  for (var i = 0; i < titulos.length; i++) {
    html += "<th>" + titulos[i] + "</th>";
  }
  html += "</tr></thead><tbody>";
  for (var j = 0; j < linhas.length; j++) {
    html += "<tr>" + linhas[j] + "</tr>";
  }
  return html + "</tbody></table></div>";
}

// Lê o valor de um campo do formulário pelo id
function valor(id) {
  return document.getElementById(id).value.trim();
}

// Mostra a data AAAA-MM-DD como DD/MM/AAAA
function dataBR(data) {
  if (!data) {
    return "";
  }
  var p = String(data).split("-");
  return p[2] + "/" + p[1] + "/" + p[0];
}
