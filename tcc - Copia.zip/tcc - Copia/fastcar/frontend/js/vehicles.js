// Página de veículos (frota): categorias à esquerda, modelos à direita

var todosVeiculos = [];

document.addEventListener("DOMContentLoaded", iniciarVeiculos);

async function iniciarVeiculos() {
  var listaCategorias = document.getElementById("category-list");
  var listaModelos = document.getElementById("model-list");
  var titulo = document.getElementById("models-title");

  // Busca a frota no backend
  try {
    todosVeiculos = await carregarVeiculos();
  } catch (erro) {
    titulo.textContent = "Frota indisponível";
    listaModelos.innerHTML = '<p class="form-message">' + escaparHtml(erro.message) + "</p>";
    return;
  }

  // Cria um botão para cada categoria que tenha veículos
  var primeira = null;
  for (var i = 0; i < categorias.length; i++) {
    if (veiculosDaCategoria(categorias[i].nome).length > 0) {
      listaCategorias.appendChild(criarBotaoCategoria(categorias[i]));
      if (primeira === null) {
        primeira = categorias[i].nome;
      }
    }
  }

  // Categoria que vem na URL (ex.: veiculos.html?categoria=SUVs)
  var pedida = new URLSearchParams(window.location.search).get("categoria");
  if (pedida !== null && veiculosDaCategoria(pedida).length > 0) {
    mostrarCategoria(pedida);
  } else if (primeira !== null) {
    mostrarCategoria(primeira);
  } else {
    titulo.textContent = "Nenhum veículo cadastrado";
  }
}

function veiculosDaCategoria(nomeCategoria) {
  var resultado = [];
  for (var i = 0; i < todosVeiculos.length; i++) {
    if (todosVeiculos[i].categoria.nome === nomeCategoria) {
      resultado.push(todosVeiculos[i]);
    }
  }
  return resultado;
}

function criarBotaoCategoria(categoria) {
  var botao = document.createElement("button");
  botao.type = "button";
  botao.className = "category-card";
  botao.dataset.category = categoria.nome;
  botao.innerHTML =
    '<div class="category-icon"><i data-lucide="' + categoria.icone + '" width="19"></i></div>' +
    "<h2>" + categoria.nome + "</h2>" +
    "<p>" + categoria.detalhe + "</p>";
  botao.addEventListener("click", function () {
    mostrarCategoria(categoria.nome);
  });
  return botao;
}

function mostrarCategoria(nomeCategoria) {
  // Destaca o botão da categoria escolhida
  var botoes = document.querySelectorAll("#category-list .category-card");
  for (var i = 0; i < botoes.length; i++) {
    if (botoes[i].dataset.category === nomeCategoria) {
      botoes[i].classList.add("is-selected");
    } else {
      botoes[i].classList.remove("is-selected");
    }
  }

  var veiculos = veiculosDaCategoria(nomeCategoria);
  document.getElementById("models-title").textContent = nomeCategoria;
  document.getElementById("models-count").textContent = veiculos.length + " modelos";

  var listaModelos = document.getElementById("model-list");
  listaModelos.innerHTML = "";
  for (var j = 0; j < veiculos.length; j++) {
    listaModelos.appendChild(criarCartaoVeiculo(veiculos[j]));
  }
  atualizarIcones();
}

function criarCartaoVeiculo(veiculo) {
  var cartao = document.createElement("div");
  cartao.className = "model-card";

  var textoBotao = "Escolher";
  if (!veiculo.disponivel) {
    textoBotao = "Indisponível";
  }

  cartao.innerHTML =
    '<div class="model-image ' + veiculo.categoria.imagem + '"></div>' +
    '<span class="model-category">' + veiculo.categoria.nome +
      (veiculo.emOferta ? ' · <b style="color:#b63f20">Oferta</b>' : "") + "</span>" +
    "<h3>" + escaparHtml(veiculo.nome) + "</h3>" +
    "<p>" + veiculo.categoria.detalhe + "</p>" +
    '<div class="model-footer">' +
      '<span class="model-price">' + htmlPreco(veiculo) +
        ' <small style="font-family:DM Sans;font-weight:500;color:#777">/dia</small></span>' +
      '<button type="button" class="select-vehicle">' + textoBotao + "</button>" +
    "</div>";

  aplicarFoto(cartao.querySelector(".model-image"), veiculo);

  var botao = cartao.querySelector(".select-vehicle");
  if (veiculo.disponivel) {
    botao.addEventListener("click", function () {
      escolherVeiculo(veiculo);
    });
  } else {
    botao.disabled = true;
  }
  return cartao;
}
