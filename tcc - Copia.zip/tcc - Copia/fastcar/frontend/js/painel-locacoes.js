// Painel > Locações: registrar, listar, finalizar e cancelar

var usuario = null;
var locacoes = [];
var veiculosDisponiveis = [];

document.addEventListener("DOMContentLoaded", async function () {
  usuario = await iniciarPainel(["VENDEDOR", "GERENTE", "ADMINISTRADOR"]);
  if (usuario === null) {
    return;
  }

  document.getElementById("form-locacao").addEventListener("submit", registrarLocacao);
  document.getElementById("veiculo").addEventListener("change", mostrarPrevia);
  document.getElementById("data-inicio").addEventListener("change", mostrarPrevia);
  document.getElementById("data-fim").addEventListener("change", mostrarPrevia);

  carregarFormulario();
  carregarLocacoes();
});

// Preenche as listas de clientes e de veículos disponíveis
async function carregarFormulario() {
  try {
    var clientes = await chamarApi("/clientes");
    var opcoes = "";
    for (var i = 0; i < clientes.length; i++) {
      opcoes += '<option value="' + clientes[i].id + '">' + escaparHtml(clientes[i].nome) + " - " + formatarCPF(clientes[i].cpf) + "</option>";
    }
    document.getElementById("cliente").innerHTML = opcoes;

    var todos = await chamarApi("/veiculos");
    veiculosDisponiveis = [];
    opcoes = "";
    for (var j = 0; j < todos.length; j++) {
      if (todos[j].status === "DISPONIVEL") {
        veiculosDisponiveis.push(todos[j]);
        opcoes += '<option value="' + todos[j].id + '">' + escaparHtml(todos[j].marca + " " + todos[j].modelo + " (" + todos[j].placa + ")") + "</option>";
      }
    }
    document.getElementById("veiculo").innerHTML = opcoes;
    mostrarPrevia();
  } catch (erro) {
    mostrarAviso(erro.message, true);
  }
}

// Mostra o valor estimado antes de registrar (o servidor refaz a conta ao salvar)
function mostrarPrevia() {
  var id = Number(document.getElementById("veiculo").value);
  var inicio = document.getElementById("data-inicio").value;
  var fim = document.getElementById("data-fim").value;
  var texto = "";

  for (var i = 0; i < veiculosDisponiveis.length; i++) {
    if (veiculosDisponiveis[i].id === id && inicio !== "" && fim !== "" && fim >= inicio) {
      var diaria = veiculosDisponiveis[i].preco_promocional || veiculosDisponiveis[i].valor_diaria;
      var dias = Math.round((new Date(fim) - new Date(inicio)) / 86400000);
      if (dias < 1) {
        dias = 1;
      }
      texto = dias + " diária(s) de " + formatarMoeda(diaria) + " = " + formatarMoeda(dias * diaria);
    }
  }
  document.getElementById("previa").textContent = texto;
}

async function carregarLocacoes() {
  try {
    locacoes = await chamarApi("/locacoes");
    mostrarTabela();
  } catch (erro) {
    mostrarAviso(erro.message, true);
  }
}

function mostrarTabela() {
  var filtro = document.getElementById("filtro-status").value;
  var podeCancelar = usuario.cargo === "GERENTE" || usuario.cargo === "ADMINISTRADOR";
  var linhas = [];

  for (var i = 0; i < locacoes.length; i++) {
    var l = locacoes[i];
    if (filtro !== "" && l.status !== filtro) {
      continue;
    }
    var acoes = "";
    if (l.status === "ATIVA") {
      acoes = '<button class="btn btn-mini btn-primario" onclick="mudarLocacao(' + l.id + ', \'finalizar\')">Finalizar</button>';
      if (podeCancelar) {
        acoes += '<button class="btn btn-mini btn-perigo" onclick="mudarLocacao(' + l.id + ', \'cancelar\')">Cancelar</button>';
      }
    }
    linhas.push(
      "<td>" + l.id + "</td>" +
      "<td>" + escaparHtml(l.cliente_nome) + "</td>" +
      "<td>" + escaparHtml(l.veiculo_marca + " " + l.veiculo_modelo) + "<br><small>" + escaparHtml(l.veiculo_placa) + "</small></td>" +
      "<td>" + dataBR(l.data_inicio) + " a " + dataBR(l.data_fim) + "</td>" +
      "<td>" + formatarMoeda(l.valor_diaria) + "</td>" +
      "<td><strong>" + formatarMoeda(l.valor_total) + "</strong></td>" +
      "<td>" + escaparHtml(l.vendedor_nome || "Site") + "</td>" +
      '<td><span class="tag ' + l.status + '">' + l.status + "</span></td>" +
      '<td class="acoes">' + acoes + "</td>"
    );
  }
  document.getElementById("tabela").innerHTML = montarTabela(["Nº", "Cliente", "Veículo", "Período", "Diária", "Total", "Atendente", "Status", "Ações"], linhas);
}

async function registrarLocacao(evento) {
  evento.preventDefault();
  try {
    var r = await chamarApi("/locacoes", "POST", {
      cliente_id: valor("cliente"),
      veiculo_id: valor("veiculo"),
      data_inicio: valor("data-inicio"),
      data_fim: valor("data-fim")
    });
    mostrarAviso("Locação registrada! Total: " + formatarMoeda(r.valor_total));
    document.getElementById("form-locacao").reset();
    carregarFormulario();
    carregarLocacoes();
  } catch (erro) {
    mostrarAviso(erro.message, true);
  }
}

// acao = "finalizar" ou "cancelar"
async function mudarLocacao(id, acao) {
  if (!confirm("Deseja " + acao + " a locação " + id + "?")) {
    return;
  }
  try {
    await chamarApi("/locacoes/" + id + "/" + acao, "PUT");
    mostrarAviso("Pronto!");
    carregarFormulario();
    carregarLocacoes();
  } catch (erro) {
    mostrarAviso(erro.message, true);
  }
}
