// Funções compartilhadas por todas as páginas

// ===== Comunicação com o backend =====
// O site é entregue pelo próprio servidor, então os endereços são relativos (ex.: "/veiculos").
// O login usa cookie de sessão; por isso o fetch envia as credenciais.

// Faz uma chamada ao servidor e devolve o JSON da resposta.
// Se o servidor responder com erro, lança um Error com a mensagem recebida.
async function chamarApi(caminho, metodo, corpo) {
  var opcoes = { method: metodo || "GET", headers: {}, credentials: "same-origin" };
  if (corpo) {
    opcoes.headers["Content-Type"] = "application/json";
    opcoes.body = JSON.stringify(corpo);
  }

  var resposta;
  try {
    resposta = await fetch(caminho, opcoes);
  } catch (erro) {
    throw new Error("Não foi possível conectar ao servidor. Verifique se ele está ligado (npm start).");
  }

  var dados = {};
  try {
    dados = await resposta.json();
  } catch (erro) {
    dados = {};
  }
  if (!resposta.ok) {
    throw new Error(dados.erro || "Erro ao comunicar com o servidor.");
  }
  return dados;
}

// ===== Veículos =====

// Converte um veículo vindo do servidor para o formato usado nas telas
function prepararVeiculo(v) {
  var chave = "CARRO";
  if (v.tipo === "MOTO") {
    chave = "MOTO";
  } else if (v.categoria) {
    chave = v.categoria;
  }
  var emOferta = v.preco_promocional !== null;
  var preco = v.valor_diaria;
  if (emOferta) {
    preco = v.preco_promocional;
  }
  return {
    id: v.id,
    nome: v.marca + " " + v.modelo,
    preco: preco,
    precoOriginal: v.valor_diaria,
    emOferta: emOferta,
    foto: v.foto,
    disponivel: v.status === "DISPONIVEL",
    categoria: buscarCategoria(chave)
  };
}

// Preço para exibir nos cartões (mostra o preço antigo riscado quando está em oferta)
function htmlPreco(veiculo) {
  if (veiculo.emOferta) {
    return '<s style="color:#999;font-weight:500;font-size:.78em">' + formatarMoeda(veiculo.precoOriginal) + "</s> " + formatarMoeda(veiculo.preco);
  }
  return formatarMoeda(veiculo.preco);
}

// Troca a imagem padrão da categoria pela foto cadastrada do veículo (quando existe)
function aplicarFoto(elemento, veiculo) {
  if (elemento && veiculo.foto) {
    elemento.style.backgroundImage = "url('" + encodeURI(veiculo.foto) + "')";
  }
}

// Busca todos os veículos no backend
async function carregarVeiculos() {
  var lista = await chamarApi("/veiculos");
  var veiculos = [];
  for (var i = 0; i < lista.length; i++) {
    veiculos.push(prepararVeiculo(lista[i]));
  }
  return veiculos;
}

// Procura um veículo pelo nome e pelo nome da categoria
function acharVeiculo(veiculos, nome, nomeCategoria) {
  for (var i = 0; i < veiculos.length; i++) {
    if (veiculos[i].nome === nome && veiculos[i].categoria.nome === nomeCategoria) {
      return veiculos[i];
    }
  }
  return null;
}

// Guarda o veículo escolhido e segue para a reserva (ou para o login)
async function escolherVeiculo(veiculo) {
  salvarSelecao({
    categoria: veiculo.categoria.nome,
    modelo: veiculo.nome,
    preco: veiculo.preco,
    veiculoId: veiculo.id
  });
  var usuario = await carregarSessao();
  if (usuario === null) {
    window.location.href = "login.html?return=reserva";
  } else {
    window.location.href = "reserva.html";
  }
}

// ===== Veículo escolhido (fica na sessionStorage até a reserva terminar) =====
function salvarSelecao(selecao) {
  sessionStorage.setItem("fastcar_pending_selection", JSON.stringify(selecao));
}

function lerSelecao() {
  var texto = sessionStorage.getItem("fastcar_pending_selection");
  if (texto === null) {
    return null;
  }
  return JSON.parse(texto);
}

function limparSelecao() {
  sessionStorage.removeItem("fastcar_pending_selection");
}

// ===== Quem está logado =====
var usuarioAtual = null;   // { id, nome, email, cargo } ou null
var sessaoPronta = null;

// Pergunta ao servidor quem está logado (só faz isso uma vez por página)
function carregarSessao() {
  if (sessaoPronta === null) {
    sessaoPronta = chamarApi("/auth/eu").then(function (dados) {
      usuarioAtual = dados.usuario;
      return usuarioAtual;
    }).catch(function () {
      return null;
    });
  }
  return sessaoPronta;
}

async function sair() {
  try {
    await chamarApi("/auth/logout", "POST");
  } catch (erro) {
    // vai para a página inicial mesmo assim
  }
  window.location.href = "/html/index.html";
}

// No menu do site: troca "Já sou cliente" por "Olá, Nome · Sair" (ou "Painel", para funcionários)
async function atualizarCabecalho() {
  var usuario = await carregarSessao();
  if (usuario === null) {
    return;
  }
  var links = document.querySelectorAll('.login-link, .mobile-nav a[href="login.html"]');
  for (var i = 0; i < links.length; i++) {
    if (usuario.cargo === "CLIENTE") {
      links[i].textContent = "Olá, " + usuario.nome.split(" ")[0] + " · Sair";
      links[i].href = "#";
      links[i].addEventListener("click", function (evento) {
        evento.preventDefault();
        sair();
      });
    } else {
      links[i].textContent = "Ir para o painel";
      links[i].href = "painel.html";
    }
  }
}

// ===== Utilitários =====

function formatarMoeda(valor) {
  return Number(valor).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

// Evita que textos virem HTML ao serem exibidos na página
function escaparHtml(texto) {
  return String(texto)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function formatarCPF(valor) {
  var d = valor.replace(/\D/g, "").slice(0, 11);
  if (d.length > 9) {
    return d.slice(0, 3) + "." + d.slice(3, 6) + "." + d.slice(6, 9) + "-" + d.slice(9);
  }
  if (d.length > 6) {
    return d.slice(0, 3) + "." + d.slice(3, 6) + "." + d.slice(6);
  }
  if (d.length > 3) {
    return d.slice(0, 3) + "." + d.slice(3);
  }
  return d;
}

function formatarTelefone(valor) {
  var d = valor.replace(/\D/g, "").slice(0, 11);
  if (d.length > 10) {
    return "(" + d.slice(0, 2) + ") " + d.slice(2, 7) + "-" + d.slice(7);
  }
  if (d.length > 6) {
    return "(" + d.slice(0, 2) + ") " + d.slice(2, 6) + "-" + d.slice(6);
  }
  if (d.length > 2) {
    return "(" + d.slice(0, 2) + ") " + d.slice(2);
  }
  return d;
}

function doisDigitos(numero) {
  if (numero < 10) {
    return "0" + numero;
  }
  return String(numero);
}

// Data de hoje no formato AAAA-MM-DD
function hojeISO() {
  var h = new Date();
  return h.getFullYear() + "-" + doisDigitos(h.getMonth() + 1) + "-" + doisDigitos(h.getDate());
}

// Soma dias a uma data AAAA-MM-DD e devolve a nova data no mesmo formato
function somarDias(dataISO, dias) {
  var partes = dataISO.split("-");
  var data = new Date(Number(partes[0]), Number(partes[1]) - 1, Number(partes[2]) + dias);
  return data.getFullYear() + "-" + doisDigitos(data.getMonth() + 1) + "-" + doisDigitos(data.getDate());
}

function atualizarIcones() {
  if (window.lucide) {
    lucide.createIcons();
  }
}

// ===== Executa em todas as páginas =====
document.addEventListener("DOMContentLoaded", function () {
  atualizarIcones();
  atualizarCabecalho();

  // Não deixa escolher datas passadas
  var campos = document.querySelectorAll('input[type="date"]');
  for (var i = 0; i < campos.length; i++) {
    if (campos[i].id === "signup-birth" || campos[i].hasAttribute("data-nascimento")) {
      campos[i].max = hojeISO();   // nascimento: só datas passadas
    } else if (campos[i].value === "") {
      campos[i].min = hojeISO();
    }
  }

  // Menu do celular
  var botao = document.getElementById("mobile-menu-button");
  var menu = document.getElementById("mobile-menu");
  if (botao && menu) {
    botao.addEventListener("click", function () {
      var aberto = menu.classList.toggle("open");
      botao.setAttribute("aria-expanded", String(aberto));
    });
  }
});
