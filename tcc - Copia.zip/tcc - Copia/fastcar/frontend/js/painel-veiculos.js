// Painel > Veículos: cadastrar, listar, pesquisar, editar e excluir

var usuario = null;
var veiculos = [];          // lista que veio do servidor
var podeEditar = false;     // só gerente e administrador

document.addEventListener("DOMContentLoaded", async function () {
  usuario = await iniciarPainel(["VENDEDOR", "GERENTE", "ADMINISTRADOR"]);
  if (usuario === null) {
    return;
  }

  podeEditar = usuario.cargo === "GERENTE" || usuario.cargo === "ADMINISTRADOR";
  if (!podeEditar) {
    // vendedor só consulta: esconde o formulário
    document.getElementById("area-formulario").classList.add("hidden-state");
  }

  document.getElementById("form-veiculo").addEventListener("submit", salvarVeiculo);
  carregarVeiculos();
});

// Busca a lista no servidor
async function carregarVeiculos() {
  try {
    veiculos = await chamarApi("/veiculos");
    mostrarTabela();
  } catch (erro) {
    mostrarAviso(erro.message, true);
  }
}

// Desenha a tabela (aplicando a pesquisa e o filtro de status)
function mostrarTabela() {
  var busca = document.getElementById("busca").value.toLowerCase();
  var status = document.getElementById("filtro-status").value;
  var linhas = [];

  for (var i = 0; i < veiculos.length; i++) {
    var v = veiculos[i];
    var texto = (v.marca + " " + v.modelo + " " + v.placa).toLowerCase();
    if (texto.indexOf(busca) === -1) {
      continue;
    }
    if (status !== "" && v.status !== status) {
      continue;
    }

    var preco = formatarMoeda(v.valor_diaria);
    if (v.preco_promocional) {
      preco = "<s>" + preco + "</s> <strong>" + formatarMoeda(v.preco_promocional) + "</strong>";
    }
    var acoes = "";
    if (podeEditar) {
      acoes = '<button class="btn btn-mini" onclick="editarVeiculo(' + v.id + ')">Editar</button>' +
              '<button class="btn btn-mini btn-perigo" onclick="excluirVeiculo(' + v.id + ')">Excluir</button>';
    }

    var foto = "";
    if (v.foto) {
      foto = ' style="background-image:url(\'' + encodeURI(v.foto) + '\')"';
    }
    linhas.push(
      '<td><span class="thumb"' + foto + "></span></td>" +
      "<td><strong>" + escaparHtml(v.marca + " " + v.modelo) + "</strong><br><small>" + v.ano + "</small></td>" +
      "<td>" + escaparHtml(v.placa) + "</td>" +
      "<td>" + escaparHtml(v.categoria || v.tipo) + "</td>" +
      "<td>" + preco + "</td>" +
      '<td><span class="tag ' + v.status + '">' + v.status + "</span></td>" +
      '<td class="acoes">' + acoes + "</td>"
    );
  }

  document.getElementById("tabela").innerHTML = montarTabela(["", "Veículo", "Placa", "Categoria", "Diária", "Status", "Ações"], linhas);
}

// Cadastra (POST) ou atualiza (PUT), dependendo de haver um id no formulário
async function salvarVeiculo(evento) {
  evento.preventDefault();

  var dados = {
    placa: valor("placa"), marca: valor("marca"), modelo: valor("modelo"), ano: valor("ano"),
    tipo: valor("tipo"), categoria: valor("categoria"), quilometragem: valor("quilometragem"),
    combustivel: valor("combustivel"), cambio: valor("cambio"), portas: valor("portas"),
    valor_diaria: valor("valor_diaria"), preco_promocional: valor("preco_promocional"),
    status: valor("status"), foto: valor("foto"), descricao: valor("descricao")
  };

  var id = valor("veiculo-id");
  try {
    if (id === "") {
      await chamarApi("/veiculos", "POST", dados);
      mostrarAviso("Veículo cadastrado!");
    } else {
      await chamarApi("/veiculos/" + id, "PUT", dados);
      mostrarAviso("Veículo atualizado!");
    }
    limparFormulario();
    carregarVeiculos();
  } catch (erro) {
    mostrarAviso(erro.message, true);
  }
}

// Coloca os dados do veículo no formulário para editar
function editarVeiculo(id) {
  for (var i = 0; i < veiculos.length; i++) {
    if (veiculos[i].id === id) {
      var v = veiculos[i];
      document.getElementById("veiculo-id").value = v.id;
      document.getElementById("placa").value = v.placa;
      document.getElementById("marca").value = v.marca;
      document.getElementById("modelo").value = v.modelo;
      document.getElementById("ano").value = v.ano;
      document.getElementById("tipo").value = v.tipo;
      document.getElementById("categoria").value = v.categoria || "";
      document.getElementById("quilometragem").value = v.quilometragem;
      document.getElementById("combustivel").value = v.combustivel || "";
      document.getElementById("cambio").value = v.cambio || "";
      document.getElementById("portas").value = v.portas || "";
      document.getElementById("valor_diaria").value = v.valor_diaria;
      document.getElementById("preco_promocional").value = v.preco_promocional || "";
      document.getElementById("status").value = v.status;
      document.getElementById("foto").value = v.foto || "";
      document.getElementById("descricao").value = v.descricao || "";
      document.getElementById("titulo-formulario").textContent = "Editar veículo";
      window.scrollTo(0, 0);
    }
  }
}

function limparFormulario() {
  document.getElementById("form-veiculo").reset();
  document.getElementById("veiculo-id").value = "";
  document.getElementById("titulo-formulario").textContent = "Cadastrar veículo";
}

async function excluirVeiculo(id) {
  if (!confirm("Excluir este veículo?")) {
    return;
  }
  try {
    await chamarApi("/veiculos/" + id, "DELETE");
    mostrarAviso("Veículo excluído.");
    carregarVeiculos();
  } catch (erro) {
    mostrarAviso(erro.message, true);
  }
}
