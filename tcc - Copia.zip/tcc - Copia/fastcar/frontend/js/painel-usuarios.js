// Painel > Usuários (somente administrador): cadastrar, editar e excluir funcionários

var usuarioLogado = null;
var usuarios = [];

document.addEventListener("DOMContentLoaded", async function () {
  usuarioLogado = await iniciarPainel(["ADMINISTRADOR"]);
  if (usuarioLogado === null) {
    return;
  }
  document.getElementById("form-usuario").addEventListener("submit", salvarUsuario);
  carregarUsuarios();
});

async function carregarUsuarios() {
  try {
    usuarios = await chamarApi("/usuarios");
    var linhas = [];
    for (var i = 0; i < usuarios.length; i++) {
      var u = usuarios[i];
      var situacao = "Ativo";
      var classe = "ATIVA";
      if (u.ativo === 0) {
        situacao = "Desativado";
        classe = "CANCELADA";
      }
      linhas.push(
        "<td><strong>" + escaparHtml(u.nome) + "</strong></td>" +
        "<td>" + escaparHtml(u.email) + "</td>" +
        "<td>" + NOMES_CARGOS[u.cargo] + "</td>" +
        '<td><span class="tag ' + classe + '">' + situacao + "</span></td>" +
        '<td class="acoes"><button class="btn btn-mini" onclick="editarUsuario(' + u.id + ')">Editar</button>' +
        '<button class="btn btn-mini btn-perigo" onclick="excluirUsuario(' + u.id + ')">Excluir</button></td>'
      );
    }
    document.getElementById("tabela").innerHTML = montarTabela(["Nome", "E-mail", "Cargo", "Situação", "Ações"], linhas);
  } catch (erro) {
    mostrarAviso(erro.message, true);
  }
}

async function salvarUsuario(evento) {
  evento.preventDefault();

  var dados = {
    nome: valor("nome"), email: valor("email"), senha: valor("senha"),
    cargo: valor("cargo"), ativo: Number(valor("ativo"))
  };

  var id = valor("usuario-id");
  try {
    if (id === "") {
      await chamarApi("/usuarios", "POST", dados);
      mostrarAviso("Usuário cadastrado!");
    } else {
      await chamarApi("/usuarios/" + id, "PUT", dados);
      mostrarAviso("Usuário atualizado!");
    }
    limparFormulario();
    carregarUsuarios();
  } catch (erro) {
    mostrarAviso(erro.message, true);
  }
}

function editarUsuario(id) {
  for (var i = 0; i < usuarios.length; i++) {
    if (usuarios[i].id === id) {
      var u = usuarios[i];
      document.getElementById("usuario-id").value = u.id;
      document.getElementById("nome").value = u.nome;
      document.getElementById("email").value = u.email;
      document.getElementById("senha").value = "";
      document.getElementById("cargo").value = u.cargo;
      document.getElementById("ativo").value = u.ativo;
      document.getElementById("titulo-formulario").textContent = "Editar usuário";
      window.scrollTo(0, 0);
    }
  }
}

function limparFormulario() {
  document.getElementById("form-usuario").reset();
  document.getElementById("usuario-id").value = "";
  document.getElementById("titulo-formulario").textContent = "Cadastrar usuário";
}

async function excluirUsuario(id) {
  if (!confirm("Excluir este usuário?")) {
    return;
  }
  try {
    await chamarApi("/usuarios/" + id, "DELETE");
    mostrarAviso("Usuário excluído.");
    carregarUsuarios();
  } catch (erro) {
    mostrarAviso(erro.message, true);
  }
}
