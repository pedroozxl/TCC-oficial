// Página inicial

document.addEventListener("DOMContentLoaded", function () {
  ligarBusca();
  mostrarDestaques();
});

// Formulário de busca: leva para a página de veículos com os filtros na URL
function ligarBusca() {
  var formulario = document.getElementById("search-form");
  if (formulario === null) {
    return;
  }
  formulario.addEventListener("submit", function (evento) {
    evento.preventDefault();
    var params = new URLSearchParams();

    var tipo = document.getElementById("search-type").value;
    var cidade = document.getElementById("search-city").value;
    var retirada = document.getElementById("search-pickup-date").value;
    var devolucao = document.getElementById("search-return-date").value;

    if (tipo) { params.set("categoria", tipo); }
    if (cidade) { params.set("cidade", cidade); }
    if (retirada) { params.set("retirada", retirada); }
    if (devolucao) { params.set("devolucao", devolucao); }

    window.location.href = "veiculos.html?" + params.toString();
  });
}

// Veículos em destaque (dados vindos do backend)
async function mostrarDestaques() {
  var lista = document.getElementById("featured-list");
  if (lista === null) {
    return;
  }

  var veiculos;
  try {
    veiculos = await carregarVeiculos();
  } catch (erro) {
    lista.innerHTML = '<p class="form-message">' + escaparHtml(erro.message) + "</p>";
    return;
  }

  var escolhidos = escolherDestaques(veiculos);
  for (var i = 0; i < escolhidos.length; i++) {
    lista.appendChild(criarCartaoDestaque(escolhidos[i], i));
  }
  atualizarIcones();
}

function criarCartaoDestaque(veiculo, posicao) {
  var selo = "Em destaque";
  if (posicao === 0) {
    selo = "Queridinho";
  }

  var cartao = document.createElement("a");
  cartao.href = "veiculos.html?categoria=" + encodeURIComponent(veiculo.categoria.nome);
  cartao.className = "home-featured-card";
  cartao.innerHTML =
    '<div class="vehicle-photo ' + veiculo.categoria.imagem + '">' +
      '<span class="pill pill-orange" style="position:absolute;z-index:2;left:12px;top:12px">' + selo + "</span>" +
    "</div>" +
    '<div class="vehicle-meta">' +
      '<span class="category">' + veiculo.categoria.nome + "</span>" +
      "<h3>" + escaparHtml(veiculo.nome) + "</h3>" +
      "<p>" + veiculo.categoria.detalhe + "</p>" +
      '<div class="price-row"><strong>' + htmlPreco(veiculo) + "</strong><span>por dia</span></div>" +
    "</div>";
  aplicarFoto(cartao.querySelector(".vehicle-photo"), veiculo);
  return cartao;
}
